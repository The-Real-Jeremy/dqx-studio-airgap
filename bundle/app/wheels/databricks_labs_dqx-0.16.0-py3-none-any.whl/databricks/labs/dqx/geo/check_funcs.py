from collections.abc import Callable
import operator as py_operator
import uuid
from typing import Literal

from pyspark.sql import Column, DataFrame
import pyspark.sql.functions as F

from databricks.labs.dqx.rule import register_rule, requires_dbr_version
from databricks.labs.dqx.check_funcs import make_condition, get_normalized_column_and_expr, get_limit_expr
from databricks.labs.dqx.errors import InvalidParameterError
from databricks.labs.dqx.utils import safe_filter_expr

POINT_TYPE = "ST_Point"
LINESTRING_TYPE = "ST_LineString"
POLYGON_TYPE = "ST_Polygon"
MULTIPOINT_TYPE = "ST_MultiPoint"
MULTILINESTRING_TYPE = "ST_MultiLineString"
MULTIPOLYGON_TYPE = "ST_MultiPolygon"
GEOMETRYCOLLECTION_TYPE = "ST_GeometryCollection"
DEFAULT_SRID = 4326

_PRECISE_TOPOLOGICAL_RELATIONSHIPS = frozenset({"CONTAINS", "COVERS", "INTERSECTS", "TOUCHES", "WITHIN"})

_PRECISE_TOPOLOGICAL_FUNCS: dict[str, str] = {
    "WITHIN": "st_within",
    "CONTAINS": "st_contains",
    "COVERS": "st_covers",
    "INTERSECTS": "st_intersects",
    "TOUCHES": "st_touches",
}

_APPROXIMATE_TOPOLOGICAL_RELATIONSHIPS = frozenset({"COVERS", "INTERSECTS"})

_PRECISE_ALIAS_SUFFIX = {
    "CONTAINS": "is_not_in_reference_geometry",
    "COVERS": "is_not_covered_by_reference_geometry_precisely",
    "INTERSECTS": "does_not_intersect_reference_geometry_precisely",
    "TOUCHES": "does_not_touch_reference_geometry",
    "WITHIN": "does_not_contain_reference_geometry",
}

_PRECISE_MESSAGE_SUFFIX = {
    "CONTAINS": "is not in the reference geometry",
    "COVERS": "is not covered by the reference geometry precisely",
    "INTERSECTS": "does not intersect the reference geometry precisely",
    "TOUCHES": "does not touch the reference geometry",
    "WITHIN": "does not contain reference geometry",
}

_APPROXIMATE_ALIAS_SUFFIX = {
    "COVERS": "is_not_covered_by_reference_geometry_approximately",
    "INTERSECTS": "does_not_intersect_reference_geometry_approximately",
}

_APPROXIMATE_MESSAGE_SUFFIX = {
    "COVERS": "is not covered by the reference geometry approximately",
    "INTERSECTS": "does not approximately intersect the reference geometry",
}


@register_rule("row")
def is_latitude(column: str | Column) -> Column:
    """Checks whether the values in the input column are valid latitudes.

    Args:
        column: column to check; can be a string column name or a column expression

    Returns:
        Column object indicating whether the values in the input column are valid latitudes
    """
    col_str_norm, col_expr_str, col_expr = get_normalized_column_and_expr(column)
    condition = ~F.when(col_expr.isNull(), F.lit(None)).otherwise(
        F.col(col_str_norm).try_cast("double").between(-90.0, 90.0)
    )
    condition_str = f"` in column `{col_expr_str}` is not a valid latitude (must be between -90 and 90)"

    return make_condition(
        condition,
        F.concat_ws("", F.lit("value `"), col_expr.cast("string"), F.lit(condition_str)),
        f"{col_str_norm}_is_not_valid_latitude",
    )


@register_rule("row")
def is_longitude(column: str | Column) -> Column:
    """Checks whether the values in the input column are valid longitudes.

    Args:
        column: column to check; can be a string column name or a column expression

    Returns:
        Column object indicating whether the values in the input column are valid longitudes
    """
    col_str_norm, col_expr_str, col_expr = get_normalized_column_and_expr(column)
    condition = ~F.when(col_expr.isNull(), F.lit(None)).otherwise(
        F.col(col_str_norm).try_cast("double").between(-180.0, 180.0)
    )
    condition_str = f"` in column `{col_expr_str}` is not a valid longitude (must be between -180 and 180)"

    return make_condition(
        condition,
        F.concat_ws("", F.lit("value `"), col_expr.cast("string"), F.lit(condition_str)),
        f"{col_str_norm}_is_not_valid_longitude",
    )


@requires_dbr_version("17.1")
@register_rule("row")
def is_geometry(column: str | Column) -> Column:
    """Checks whether the values in the input column are valid geometries.

    Args:
        column: column to check; can be a string column name or a column expression

    Returns:
        Column object indicating whether the values in the input column are valid geometries

    Note:
        This function requires Databricks serverless compute or runtime 17.1 or above.
    """
    col_str_norm, col_expr_str, col_expr = get_normalized_column_and_expr(column)
    # NOTE: This function is currently only available in Databricks runtime 17.1 or above or in
    #   Databricks SQL, due to the use of the `try_to_geometry` function.
    geometry_col = F.expr(f"try_to_geometry({col_str_norm})")
    condition = F.when(col_expr.isNull(), F.lit(None)).otherwise(geometry_col.isNull())
    condition_str = f"` in column `{col_expr_str}` is not a geometry"

    return make_condition(
        condition,
        F.concat_ws("", F.lit("value `"), col_expr.cast("string"), F.lit(condition_str)),
        f"{col_str_norm}_is_not_geometry",
    )


@requires_dbr_version("17.1")
@register_rule("row")
def is_geography(column: str | Column) -> Column:
    """Checks whether the values in the input column are valid geographies.

    Args:
        column: column to check; can be a string column name or a column expression

    Returns:
        Column object indicating whether the values in the input column are valid geographies

    Note:
        This function requires Databricks serverless compute or runtime 17.1 or above.
    """
    col_str_norm, col_expr_str, col_expr = get_normalized_column_and_expr(column)
    # NOTE: This function is currently only available in Databricks runtime 17.1 or above or in
    #   Databricks SQL, due to the use of the `try_to_geography` function.
    geometry_col = F.expr(f"try_to_geography({col_str_norm})")
    condition = F.when(col_expr.isNull(), F.lit(None)).otherwise(geometry_col.isNull())
    condition_str = f"` in column `{col_expr_str}` is not a geography"

    return make_condition(
        condition,
        F.concat_ws("", F.lit("value `"), col_expr.cast("string"), F.lit(condition_str)),
        f"{col_str_norm}_is_not_geography",
    )


@requires_dbr_version("17.1")
@register_rule("row")
def is_point(column: str | Column) -> Column:
    """Checks whether the values in the input column are point geometries.

    Args:
        column: column to check; can be a string column name or a column expression

    Returns:
        Column object indicating whether the values in the input column are point geometries

    Note:
        This function requires Databricks serverless compute or runtime 17.1 or above.
    """
    col_str_norm, col_expr_str, col_expr = get_normalized_column_and_expr(column)
    # NOTE: This function is currently only available in Databricks runtime 17.1 or above or in
    #   Databricks SQL, due to the use of the `try_to_geometry` and `st_geometrytype` functions.
    geom_cond = F.expr(f"try_to_geometry({col_str_norm}) IS NULL")
    geom_type_cond = F.expr(f"st_geometrytype(try_to_geometry({col_str_norm})) <> '{POINT_TYPE}'")
    condition = F.when(col_expr.isNull(), F.lit(None)).otherwise(geom_cond | geom_type_cond)
    condition_str = f"` in column `{col_expr_str}` is not a point geometry"
    return make_condition(
        condition,
        F.concat_ws("", F.lit("value `"), col_expr.cast("string"), F.lit(condition_str)),
        f"{col_str_norm}_is_not_point",
    )


@requires_dbr_version("17.1")
@register_rule("row")
def is_linestring(column: str | Column) -> Column:
    """Checks whether the values in the input column are linestring geometries.

    Args:
        column: column to check; can be a string column name or a column expression

    Returns:
        Column object indicating whether the values in the input column are linestring geometries

    Note:
        This function requires Databricks serverless compute or runtime 17.1 or above.
    """
    col_str_norm, col_expr_str, col_expr = get_normalized_column_and_expr(column)
    # NOTE: This function is currently only available in Databricks runtime 17.1 or above or in
    #   Databricks SQL, due to the use of the `try_to_geometry` and `st_geometrytype` functions.
    geom_cond = F.expr(f"try_to_geometry({col_str_norm}) IS NULL")
    geom_type_cond = F.expr(f"st_geometrytype(try_to_geometry({col_str_norm})) <> '{LINESTRING_TYPE}'")
    condition = F.when(col_expr.isNull(), F.lit(None)).otherwise(geom_cond | geom_type_cond)
    condition_str = f"` in column `{col_expr_str}` is not a linestring geometry"
    return make_condition(
        condition,
        F.concat_ws("", F.lit("value `"), col_expr.cast("string"), F.lit(condition_str)),
        f"{col_str_norm}_is_not_linestring",
    )


@requires_dbr_version("17.1")
@register_rule("row")
def is_polygon(column: str | Column) -> Column:
    """Checks whether the values in the input column are polygon geometries.

    Args:
        column: column to check; can be a string column name or a column expression

    Returns:
        Column object indicating whether the values in the input column are polygon geometries

    Note:
        This function requires Databricks serverless compute or runtime 17.1 or above.
    """
    col_str_norm, col_expr_str, col_expr = get_normalized_column_and_expr(column)
    # NOTE: This function is currently only available in Databricks runtime 17.1 or above or in
    #   Databricks SQL, due to the use of the `try_to_geometry` and `st_geometrytype` functions.
    geom_cond = F.expr(f"try_to_geometry({col_str_norm}) IS NULL")
    geom_type_cond = F.expr(f"st_geometrytype(try_to_geometry({col_str_norm})) <> '{POLYGON_TYPE}'")
    condition = F.when(col_expr.isNull(), F.lit(None)).otherwise(geom_cond | geom_type_cond)
    condition_str = f"` in column `{col_expr_str}` is not a polygon geometry"
    return make_condition(
        condition,
        F.concat_ws("", F.lit("value `"), col_expr.cast("string"), F.lit(condition_str)),
        f"{col_str_norm}_is_not_polygon",
    )


@requires_dbr_version("17.1")
@register_rule("row")
def is_multipoint(column: str | Column) -> Column:
    """Checks whether the values in the input column are multipoint geometries.

    Args:
        column: column to check; can be a string column name or a column expression

    Returns:
        Column object indicating whether the values in the input column are multipoint geometries

    Note:
        This function requires Databricks serverless compute or runtime 17.1 or above.
    """
    col_str_norm, col_expr_str, col_expr = get_normalized_column_and_expr(column)
    # NOTE: This function is currently only available in Databricks runtime 17.1 or above or in
    #   Databricks SQL, due to the use of the `try_to_geometry` and `st_geometrytype` functions.
    geom_cond = F.expr(f"try_to_geometry({col_str_norm}) IS NULL")
    geom_type_cond = F.expr(f"st_geometrytype(try_to_geometry({col_str_norm})) <> '{MULTIPOINT_TYPE}'")
    condition = F.when(col_expr.isNull(), F.lit(None)).otherwise(geom_cond | geom_type_cond)
    condition_str = f"` in column `{col_expr_str}` is not a multipoint geometry"
    return make_condition(
        condition,
        F.concat_ws("", F.lit("value `"), col_expr.cast("string"), F.lit(condition_str)),
        f"{col_str_norm}_is_not_multipoint",
    )


@requires_dbr_version("17.1")
@register_rule("row")
def is_multilinestring(column: str | Column) -> Column:
    """Checks whether the values in the input column are multilinestring geometries.

    Args:
        column: column to check; can be a string column name or a column expression

    Returns:
        Column object indicating whether the values in the input column are multilinestring geometries

    Note:
        This function requires Databricks serverless compute or runtime 17.1 or above.
    """
    col_str_norm, col_expr_str, col_expr = get_normalized_column_and_expr(column)
    # NOTE: This function is currently only available in Databricks runtime 17.1 or above or in
    #   Databricks SQL, due to the use of the `try_to_geometry` and `st_geometrytype` functions.
    geom_cond = F.expr(f"try_to_geometry({col_str_norm}) IS NULL")
    geom_type_cond = F.expr(f"st_geometrytype(try_to_geometry({col_str_norm})) <> '{MULTILINESTRING_TYPE}'")
    condition = F.when(col_expr.isNull(), F.lit(None)).otherwise(geom_cond | geom_type_cond)
    condition_str = f"` in column `{col_expr_str}` is not a multilinestring geometry"
    return make_condition(
        condition,
        F.concat_ws("", F.lit("value `"), col_expr.cast("string"), F.lit(condition_str)),
        f"{col_str_norm}_is_not_multilinestring",
    )


@requires_dbr_version("17.1")
@register_rule("row")
def is_multipolygon(column: str | Column) -> Column:
    """Checks whether the values in the input column are multipolygon geometries.

    Args:
        column: column to check; can be a string column name or a column expression

    Returns:
        Column object indicating whether the values in the input column are multipolygon geometries

    Note:
        This function requires Databricks serverless compute or runtime 17.1 or above.
    """
    col_str_norm, col_expr_str, col_expr = get_normalized_column_and_expr(column)
    # NOTE: This function is currently only available in Databricks runtime 17.1 or above or in
    #   Databricks SQL, due to the use of the `try_to_geometry` and `st_geometrytype` functions.
    geom_cond = F.expr(f"try_to_geometry({col_str_norm}) IS NULL")
    geom_type_cond = F.expr(f"st_geometrytype(try_to_geometry({col_str_norm})) <> '{MULTIPOLYGON_TYPE}'")
    condition = F.when(col_expr.isNull(), F.lit(None)).otherwise(geom_cond | geom_type_cond)
    condition_str = f"` in column `{col_expr_str}` is not a multipolygon geometry"
    return make_condition(
        condition,
        F.concat_ws("", F.lit("value `"), col_expr.cast("string"), F.lit(condition_str)),
        f"{col_str_norm}_is_not_multipolygon",
    )


@requires_dbr_version("17.1")
@register_rule("row")
def is_geometrycollection(column: str | Column) -> Column:
    """Checks whether the values in the input column are geometrycollection geometries.

    Args:
        column: column to check; can be a string column name or a column expression

    Returns:
        Column object indicating whether the values in the input column are geometrycollection geometries

    Note:
        This function requires Databricks serverless compute or runtime 17.1 or above.
    """
    col_str_norm, col_expr_str, col_expr = get_normalized_column_and_expr(column)
    # NOTE: This function is currently only available in Databricks runtime 17.1 or above or in
    #   Databricks SQL, due to the use of the `try_to_geometry` and `st_geometrytype` functions.
    geom_cond = F.expr(f"try_to_geometry({col_str_norm}) IS NULL")
    geom_type_cond = F.expr(f"st_geometrytype(try_to_geometry({col_str_norm})) <> '{GEOMETRYCOLLECTION_TYPE}'")
    condition = F.when(col_expr.isNull(), F.lit(None)).otherwise(geom_cond | geom_type_cond)
    condition_str = f"` in column `{col_expr_str}` is not a geometrycollection geometry"
    return make_condition(
        condition,
        F.concat_ws("", F.lit("value `"), col_expr.cast("string"), F.lit(condition_str)),
        f"{col_str_norm}_is_not_geometrycollection",
    )


@requires_dbr_version("17.1")
@register_rule("row")
def is_ogc_valid(column: str | Column) -> Column:
    """Checks whether the values in the input column are valid geometries in the OGC sense.

    Args:
        column: column to check; can be a string column name or a column expression

    Returns:
        Column object indicating whether the values in the input column are valid geometries

    Note:
        This function requires Databricks serverless compute or runtime 17.1 or above.
    """
    col_str_norm, col_expr_str, col_expr = get_normalized_column_and_expr(column)
    # NOTE: This function is currently only available in Databricks runtime 17.1 or above or in
    #   Databricks SQL, due to the use of the `try_to_geometry` and `st_isvalid` functions.
    geom_cond = F.expr(f"try_to_geometry({col_str_norm}) IS NULL")
    geom_type_cond = F.expr(f"NOT st_isvalid(try_to_geometry({col_str_norm}))")
    condition = F.when(col_expr.isNull(), F.lit(None)).otherwise(geom_cond | geom_type_cond)
    condition_str = f"` in column `{col_expr_str}` is not a valid geometry (in the OGC sense)"

    return make_condition(
        condition,
        F.concat_ws("", F.lit("value `"), col_expr.cast("string"), F.lit(condition_str)),
        f"{col_str_norm}_is_not_valid_geometry",
    )


@requires_dbr_version("17.1")
@register_rule("row")
def is_non_empty_geometry(column: str | Column) -> Column:
    """Checks whether the values in the input column are empty geometries.

    Args:
        column: column to check; can be a string column name or a column expression

    Returns:
        Column object indicating whether the values in the input column are empty geometries

    Note:
        This function requires Databricks serverless compute or runtime 17.1 or above.
    """
    col_str_norm, col_expr_str, col_expr = get_normalized_column_and_expr(column)
    # NOTE: This function is currently only available in Databricks runtime 17.1 or above or in
    #   Databricks SQL, due to the use of the `try_to_geometry` and `st_isempty` functions.
    geom_cond = F.expr(f"try_to_geometry({col_str_norm}) IS NULL")
    geom_type_cond = F.expr(f"st_isempty(try_to_geometry({col_str_norm}))")
    condition = F.when(col_expr.isNull(), F.lit(None)).otherwise(geom_cond | geom_type_cond)
    condition_str = f"` in column `{col_expr_str}` is an empty geometry"

    return make_condition(
        condition,
        F.concat_ws("", F.lit("value `"), col_expr.cast("string"), F.lit(condition_str)),
        f"{col_str_norm}_is_empty_geometry",
    )


@requires_dbr_version("17.1")
@register_rule("row")
def is_not_null_island(column: str | Column) -> Column:
    """Checks whether the values in the input column are NULL island geometries (e.g. POINT(0 0), POINTZ(0 0 0), or
    POINTZM(0 0 0 0)).

    Args:
        column: column to check; can be a string column name or a column expression

    Returns:
        Column object indicating whether the values in the input column are NULL island geometries

    Note:
        This function requires Databricks serverless compute or runtime 17.1 or above.
    """
    col_str_norm, col_expr_str, col_expr = get_normalized_column_and_expr(column)
    # NOTE: This function is currently only available in Databricks runtime 17.1 or above or in
    #   Databricks SQL, due to the use of the `try_to_geometry`, `st_geometrytype`, `st_x`, and `st_y` functions.
    try_geom_expr = f"try_to_geometry({col_str_norm})"
    geom_cond = F.expr(f"{try_geom_expr} IS NULL")

    is_point_cond = F.expr(f"st_geometrytype({try_geom_expr}) = '{POINT_TYPE}'")
    null_xy_cond = F.expr(f"st_x({try_geom_expr}) = 0.0 AND st_y({try_geom_expr}) = 0.0")
    null_z_cond = F.expr(f"st_z({try_geom_expr}) IS NULL OR st_z({try_geom_expr}) = 0.0")
    null_m_cond = F.expr(f"st_m({try_geom_expr}) IS NULL OR st_m({try_geom_expr}) = 0.0")

    is_point_null_island = is_point_cond & null_xy_cond & null_z_cond & null_m_cond
    condition = F.when(col_expr.isNull(), F.lit(None)).otherwise(~geom_cond & is_point_cond & is_point_null_island)
    condition_str = f"column `{col_expr_str}` contains a null island"

    return make_condition(
        condition,
        F.lit(condition_str),
        f"{col_str_norm}_contains_null_island",
    )


@requires_dbr_version("17.1")
@register_rule("row")
def has_dimension(column: str | Column, dimension: int) -> Column:
    """Checks whether the geometries/geographies in the input column have a given dimension.

    Args:
        column: column to check; can be a string column name or a column expression
        dimension: required dimension of the geometries/geographies

    Returns:
        Column object indicating whether the geometries/geographies in the input column have a given dimension

    Note:
        This function requires Databricks serverless compute or runtime 17.1 or above.
    """
    col_str_norm, col_expr_str, col_expr = get_normalized_column_and_expr(column)
    # NOTE: This function is currently only available in Databricks runtime 17.1 or above or in
    #   Databricks SQL, due to the use of the `try_to_geometry` and `st_dimension` functions.
    geom_cond = F.expr(f"try_to_geometry({col_str_norm}) IS NULL")
    geom_type_cond = F.expr(f"st_dimension(try_to_geometry({col_str_norm})) <> {dimension}")
    condition = F.when(col_expr.isNull(), F.lit(None)).otherwise(geom_cond | geom_type_cond)
    condition_str = f"` in column `{col_expr_str}` does not have the required dimension ({dimension})"

    return make_condition(
        condition,
        F.concat_ws("", F.lit("value `"), col_expr.cast("string"), F.lit(condition_str)),
        f"{col_str_norm}_does_not_have_required_geo_dimension",
    )


@requires_dbr_version("17.1")
@register_rule("row")
def has_x_coordinate_between(column: str | Column, min_value: float, max_value: float) -> Column:
    """Checks whether the x coordinates of the geometries in the input column are between a given range.

    Args:
        column: column to check; can be a string column name or a column expression
        min_value: minimum value of the x coordinates
        max_value: maximum value of the x coordinates

    Returns:
        Column object indicating whether the x coordinates of the geometries in the input column are between a given range

    Note:
        This function requires Databricks serverless compute or runtime 17.1 or above.
    """
    col_str_norm, col_expr_str, col_expr = get_normalized_column_and_expr(column)
    # NOTE: This function is currently only available in Databricks runtime 17.1 or above or in
    #   Databricks SQL, due to the use of the `try_to_geometry`, `st_xmax` and `st_xmin` functions.
    geom_cond = F.expr(f"try_to_geometry({col_str_norm}) IS NULL")
    geom_type_cond = F.expr(
        f"st_xmax(try_to_geometry({col_str_norm})) > {max_value} OR st_xmin(try_to_geometry({col_str_norm})) < {min_value}"
    )
    condition = F.when(col_expr.isNull(), F.lit(None)).otherwise(geom_cond | geom_type_cond)
    condition_str = f"` in column `{col_expr_str}` has x coordinates outside the range [{min_value}, {max_value}]"

    return make_condition(
        condition,
        F.concat_ws("", F.lit("value `"), col_expr.cast("string"), F.lit(condition_str)),
        f"{col_str_norm}_has_x_coordinates_outside_range",
    )


@requires_dbr_version("17.1")
@register_rule("row")
def has_y_coordinate_between(column: str | Column, min_value: float, max_value: float) -> Column:
    """Checks whether the y coordinates of the geometries in the input column are between a given range.

    Args:
        column: column to check; can be a string column name or a column expression
        min_value: minimum value of the y coordinates
        max_value: maximum value of the y coordinates

    Returns:
        Column object indicating whether the y coordinates of the geometries in the input column are between a given range

    Note:
        This function requires Databricks serverless compute or runtime 17.1 or above.
    """
    col_str_norm, col_expr_str, col_expr = get_normalized_column_and_expr(column)
    # NOTE: This function is currently only available in Databricks runtime 17.1 or above or in
    #   Databricks SQL, due to the use of the `try_to_geometry`, `st_ymax` and `st_ymin` functions.
    geom_cond = F.expr(f"try_to_geometry({col_str_norm}) IS NULL")
    geom_type_cond = F.expr(
        f"st_ymax(try_to_geometry({col_str_norm})) > {max_value} OR st_ymin(try_to_geometry({col_str_norm})) < {min_value}"
    )
    condition = F.when(col_expr.isNull(), F.lit(None)).otherwise(geom_cond | geom_type_cond)
    condition_str = f"` in column `{col_expr_str}` has y coordinates outside the range [{min_value}, {max_value}]"

    return make_condition(
        condition,
        F.concat_ws("", F.lit("value `"), col_expr.cast("string"), F.lit(condition_str)),
        f"{col_str_norm}_has_y_coordinates_outside_range",
    )


@requires_dbr_version("17.1")
@register_rule("row")
def is_area_equal_to(
    column: str | Column, value: int | float | str | Column, srid: int | None = 3857, geodesic: bool = False
) -> Column:
    """
    Checks if the areas of values in a geometry or geography column are equal to a specified value. By default, the 2D
    Cartesian area in WGS84 (Pseudo-Mercator) with units of meters squared is used. An SRID can be specified to
    transform the input values and compute areas with specific units of measure.

    Args:
        column: Column to check; can be a string column name or a column expression
        value: Value to use in the condition as number, column name or sql expression
        srid: Optional integer SRID to use for computing the area of the geometry or geography value (default `None`).
            If an SRID is provided, the input value is translated and area is calculated using the units of measure of
            the specified coordinate reference system (e.g. meters squared for `srid=3857`).
        geodesic: Whether to use the 2D geodesic area (default `False`).

    Returns:
        Column object indicating whether the area the geometries in the input column are equal to the provided value

    Note:
        This function requires Databricks serverless compute or runtime 17.1 or above.
    """
    return _compare_spatial_sql_function_result(
        column,
        value,
        spatial_function="st_area",
        spatial_quantity_label="area",
        spatial_quantity_name="area",
        compare_op=py_operator.ne,
        compare_op_label="not equal to",
        compare_op_name="not_equal_to",
        srid=srid,
        geodesic=geodesic,
    )


@requires_dbr_version("17.1")
@register_rule("row")
def is_area_not_equal_to(
    column: str | Column, value: int | float | str | Column, srid: int | None = 3857, geodesic: bool = False
) -> Column:
    """
    Checks if the areas of values in a geometry column are not equal to a specified value. By default, the 2D
    Cartesian area in WGS84 (Pseudo-Mercator) with units of meters squared is used. An SRID can be specified to
    transform the input values and compute areas with specific units of measure.

    Args:
        column: Column to check; can be a string column name or a column expression
        value: Value to use in the condition as number, column name or sql expression
        srid: Optional integer SRID to use for computing the area of the geometry or geography value (default `None`).
            If an SRID is provided, the input value is translated and area is calculated using the units of measure of
            the specified coordinate reference system (e.g. meters squared for `srid=3857`).
        geodesic: Whether to use the 2D geodesic area (default `False`).

    Returns:
        Column object indicating whether the area the geometries in the input column are not equal to the provided value

    Note:
        This function requires Databricks serverless compute or runtime 17.1 or above.
    """
    return _compare_spatial_sql_function_result(
        column,
        value,
        spatial_function="st_area",
        spatial_quantity_label="area",
        spatial_quantity_name="area",
        compare_op=py_operator.eq,
        compare_op_label="equal to",
        compare_op_name="equal_to",
        srid=srid,
        geodesic=geodesic,
    )


@requires_dbr_version("17.1")
@register_rule("row")
def is_area_not_greater_than(
    column: str | Column, value: int | float | str | Column, srid: int | None = 3857, geodesic: bool = False
) -> Column:
    """
    Checks if the areas of values in a geometry column are not greater than a specified limit. By default, the 2D
    Cartesian area in WGS84 (Pseudo-Mercator) with units of meters squared is used. An SRID can be specified to
    transform the input values and compute areas with specific units of measure.

    Args:
        column: Column to check; can be a string column name or a column expression
        value: Value to use in the condition as number, column name or sql expression
        srid: Optional integer SRID to use for computing the area of the geometry or geography value (default `None`).
            If an SRID is provided, the input value is translated and area is calculated using the units of measure of
            the specified coordinate reference system (e.g. meters squared for `srid=3857`).
        geodesic: Whether to use the 2D geodesic area (default `False`).

    Returns:
        Column object indicating whether the area the geometries in the input column is greater than the provided value

    Note:
        This function requires Databricks serverless compute or runtime 17.1 or above.
    """
    return _compare_spatial_sql_function_result(
        column,
        value,
        spatial_function="st_area",
        spatial_quantity_label="area",
        spatial_quantity_name="area",
        compare_op=py_operator.gt,
        compare_op_label="greater than",
        compare_op_name="greater_than",
        srid=srid,
        geodesic=geodesic,
    )


@requires_dbr_version("17.1")
@register_rule("row")
def is_area_not_less_than(
    column: str | Column, value: int | float | str | Column, srid: int | None = 3857, geodesic: bool = False
) -> Column:
    """
    Checks if the areas of values in a geometry column are not less than a specified limit. By default, the 2D
    Cartesian area in WGS84 (Pseudo-Mercator) with units of meters squared is used. An SRID can be specified to
    transform the input values and compute areas with specific units of measure.

    Args:
        column: Column to check; can be a string column name or a column expression
        value: Value to use in the condition as number, column name or sql expression
        srid: Optional integer SRID to use for computing the area of the geometry or geography value (default `None`).
            If an SRID is provided, the input value is translated and area is calculated using the units of measure of
            the specified coordinate reference system (e.g. meters squared for `srid=3857`).
        geodesic: Whether to use the 2D geodesic area (default `False`).

    Returns:
        Column object indicating whether the area the geometries in the input column is less than the provided value

    Note:
        This function requires Databricks serverless compute or runtime 17.1 or above.
    """
    return _compare_spatial_sql_function_result(
        column,
        value,
        spatial_function="st_area",
        spatial_quantity_label="area",
        spatial_quantity_name="area",
        compare_op=py_operator.lt,
        compare_op_label="less than",
        compare_op_name="less_than",
        srid=srid,
        geodesic=geodesic,
    )


@requires_dbr_version("17.1")
@register_rule("row")
def is_num_points_equal_to(column: str | Column, value: int | float | str | Column) -> Column:
    """
    Checks if the number of coordinate pairs in values of a geometry column is equal to a specified value.

    Args:
        column: Column to check; can be a string column name or a column expression
        value: Value to use in the condition as number, column name or sql expression

    Returns:
        Column object indicating whether the number of coordinate pairs in the geometries of the input column is
        equal to the provided value

    Note:
        This function requires Databricks serverless compute or runtime 17.1 or above.
    """
    return _compare_spatial_sql_function_result(
        column,
        value,
        spatial_function="st_npoints",
        spatial_quantity_label="number of coordinates",
        spatial_quantity_name="num_points",
        compare_op=py_operator.ne,
        compare_op_label="not equal to",
        compare_op_name="not_equal_to",
    )


@requires_dbr_version("17.1")
@register_rule("row")
def is_num_points_not_equal_to(column: str | Column, value: int | float | str | Column) -> Column:
    """
    Checks if the number of coordinate pairs in values of a geometry column is not equal to a specified value.

    Args:
        column: Column to check; can be a string column name or a column expression
        value: Value to use in the condition as number, column name or sql expression

    Returns:
        Column object indicating whether the number of coordinate pairs in the geometries of the input column is not
        equal to the provided value

    Note:
        This function requires Databricks serverless compute or runtime 17.1 or above.
    """
    return _compare_spatial_sql_function_result(
        column,
        value,
        spatial_function="st_npoints",
        spatial_quantity_label="number of coordinates",
        spatial_quantity_name="num_points",
        compare_op=py_operator.eq,
        compare_op_label="equal to",
        compare_op_name="equal_to",
    )


@requires_dbr_version("17.1")
@register_rule("row")
def is_num_points_not_greater_than(column: str | Column, value: int | float | str | Column) -> Column:
    """
    Checks if the number of coordinate pairs in the values of a geometry column is not greater than a specified limit.

    Args:
        column: Column to check; can be a string column name or a column expression
        value: Value to use in the condition as number, column name or sql expression

    Returns:
        Column object indicating whether the number of coordinate pairs in the geometries of the input column is
        greater than the provided value

    Note:
        This function requires Databricks serverless compute or runtime 17.1 or above.
    """
    return _compare_spatial_sql_function_result(
        column,
        value,
        spatial_function="st_npoints",
        spatial_quantity_label="number of coordinates",
        spatial_quantity_name="num_points",
        compare_op=py_operator.gt,
        compare_op_label="greater than",
        compare_op_name="greater_than",
    )


@requires_dbr_version("17.1")
@register_rule("row")
def is_num_points_not_less_than(column: str | Column, value: int | float | str | Column) -> Column:
    """
    Checks if the number of coordinate pairs in values of a geometry column is not less than a specified limit.

    Args:
        column: Column to check; can be a string column name or a column expression
        value: Value to use in the condition as number, column name or sql expression

    Returns:
        Column object indicating whether the number of coordinate pairs in the geometries of the input column is
        less than the provided value

    Note:
        This function requires Databricks serverless compute or runtime 17.1 or above.
    """
    return _compare_spatial_sql_function_result(
        column,
        value,
        spatial_function="st_npoints",
        spatial_quantity_label="number of coordinates",
        spatial_quantity_name="num_points",
        compare_op=py_operator.lt,
        compare_op_label="less than",
        compare_op_name="less_than",
    )


def _compare_spatial_sql_function_result(
    column: str | Column,
    value: int | float | str | Column,
    spatial_function: str,
    spatial_quantity_label: str,
    spatial_quantity_name: str,
    compare_op: Callable[[Column, Column], Column],
    compare_op_label: str,
    compare_op_name: str,
    srid: int | None = None,
    geodesic: bool = False,
) -> Column:
    """
    Compares the results from applying a spatial SQL function (e.g. `st_area`) on a geometry column against a limit
    using the specified comparison operator.

    Args:
        column: Column to check; can be a string column name or a column expression
        value: Value to use in the condition as number, column name or sql expression
        spatial_function: Spatial SQL function as a string (e.g. `st_npoints`)
        spatial_quantity_label: Spatial quantity label (e.g. `number of coordinates` )
        spatial_quantity_name: Spatial quantity identifier (e.g. `num_points`)
        compare_op: Comparison operator (e.g., `operator.gt`, `operator.lt`).
        compare_op_label: Human-readable label for the comparison (e.g., 'greater than').
        compare_op_name: Name identifier for the comparison (e.g., 'greater_than').
        srid: Optional integer SRID for computing measurements on the converted geometry or geography value (default `None`).
        geodesic: Whether to convert the input column to a geography type for computing geodesic distances.

    Returns:
        Column object indicating whether the area the geometries in the input column is less than the provided limit

    Note:
        This function requires Databricks serverless compute or runtime 17.1 or above.
    """
    col_str_norm, col_expr_str, col_expr = get_normalized_column_and_expr(column)
    value_expr = get_limit_expr(value)
    # NOTE: This function is currently only available in Databricks runtime 17.1 or above or in
    #   Databricks SQL, due to the use of the `try_to_geometry` and `st_area` functions.
    if geodesic:
        spatial_conversion_expr = f"try_to_geography({col_str_norm})"
        spatial_data_type = "geography"
    elif srid:
        spatial_conversion_expr = f"st_transform(st_setsrid(try_to_geometry({col_str_norm}), {DEFAULT_SRID}), {srid})"
        spatial_data_type = "geometry"
    else:
        spatial_conversion_expr = f"try_to_geometry({col_str_norm})"
        spatial_data_type = "geometry"

    is_valid_cond = F.expr(f"{spatial_conversion_expr} IS NULL")
    is_valid_message = F.concat_ws(
        "",
        F.lit("value `"),
        col_expr.cast("string"),
        F.lit(f"` in column `{col_expr_str}` is not a valid {spatial_data_type}"),
    )
    compare_cond = compare_op(F.expr(f"{spatial_function}({spatial_conversion_expr})"), value_expr)
    compare_message = F.concat_ws(
        "",
        F.lit("value `"),
        col_expr.cast("string"),
        F.lit(f"` in column `{col_expr_str}` has {spatial_quantity_label} {compare_op_label} value: "),
        value_expr.cast("string"),
    )
    condition = F.when(col_expr.isNull(), F.lit(None)).otherwise(is_valid_cond | compare_cond)

    return make_condition(
        condition,
        F.when(is_valid_cond, is_valid_message).otherwise(compare_message),
        f"{col_str_norm}_{spatial_quantity_name}_{compare_op_name}_limit",
    )


@requires_dbr_version("17.1")
@register_rule("dataset")
def are_polygons_mutually_disjoint(
    column: str | Column,
    row_filter: str | None = None,
) -> tuple[Column, Callable]:
    """
    Checks if the polygons in a geometry column are mutually disjoint. By default,
    native Spark spatial intersections are used.

    Args:
        column: Column to check; can be a string column name or a column expression
        row_filter: Optional SQL expression to filter rows before checking for intersections.

    Returns:
        A tuple of:
            - A Spark Column representing the condition for mutual disjoint violations.
            - A closure that applies the polygon intersection check and adds the condition column to the DataFrame.


    Note:
        This function requires Databricks runtime 17.1 or above.
        This check performs a self-join over all valid polygons in the input DataFrame,
        which is O(n²). Use ``row_filter`` to limit the rows evaluated on large tables.
        Photon activation is suggested to use optimised spatial computation.
    """

    col_str_norm, col_expr_str, col_expr = get_normalized_column_and_expr(column)
    unique_str = uuid.uuid4().hex
    condition_col = f"__intersect_condition_{col_str_norm}_{unique_str}"
    row_id_col = f"__row_hash_{unique_str}"
    geom_temp_col = f"__geom_temp_{unique_str}"

    def apply(df: DataFrame) -> DataFrame:
        """Identify rows whose polygon intersects with at least one other polygon.

        Computes a deterministic hash of each row. Exact duplicates (same hash)
        are flagged directly. Unique rows undergo a spatial self-join to detect
        intersections. The original DataFrame is returned with all rows preserved
        and a boolean condition column indicating violations.

        Args:
            df: Input DataFrame containing the geometry column to check.

        Returns:
            DataFrame with an additional boolean column marking rows whose polygon
            intersects with at least one other polygon in the dataset.
        """
        # Hash all rows first (needed for final join to preserve all rows)
        df_with_hash = df.withColumn(row_id_col, F.xxhash64(F.struct("*")))

        # Apply filter after hashing (so hash is available for final join to preserve all rows)
        filtered_df = df_with_hash.filter(safe_filter_expr(row_filter)) if row_filter is not None else df_with_hash

        duplicates_df = filtered_df.groupBy(row_id_col).count().filter("count > 1").select(row_id_col)

        prep_df = (
            filtered_df.dropDuplicates([row_id_col])
            .filter(col_expr.isNotNull())
            .withColumn(geom_temp_col, F.expr(f"try_to_geometry({col_expr_str})"))
            .filter(F.col(geom_temp_col).isNotNull())
            .filter(F.expr(f"st_geometrytype(`{geom_temp_col}`) IN ('{POLYGON_TYPE}', '{MULTIPOLYGON_TYPE}')"))
        )

        prep_a = prep_df.alias("a")
        prep_b = prep_df.alias("b")

        intersecting_ids_df = prep_a.join(
            prep_b,
            (F.col(f"b.{row_id_col}") > F.col(f"a.{row_id_col}"))
            & F.expr(f"st_intersects(a.`{geom_temp_col}`, b.`{geom_temp_col}`)"),
        ).select(F.explode(F.array(F.col(f"a.{row_id_col}"), F.col(f"b.{row_id_col}"))).alias(row_id_col))

        all_violating_ids = duplicates_df.union(intersecting_ids_df).distinct().withColumn(condition_col, F.lit(True))

        result_df = df_with_hash.join(
            all_violating_ids,
            on=row_id_col,
            how="left",
        ).drop(row_id_col)

        return result_df.na.fill(False, subset=[condition_col])

    condition = make_condition(
        condition=F.col(condition_col),
        message=F.concat_ws(
            "",
            F.lit("value `"),
            col_expr.cast("string"),
            F.lit(f"` in column `{col_expr_str}` intersects with at least one other polygon"),
        ),
        alias=f"{col_str_norm}_not_mutually_disjoint",
    )

    return condition, apply


def _has_topological_relationship_precise(
    column: str | Column,
    reference_geometry: str | bytes | Column,
    convert_column: bool = False,
    convert_reference_geometry: bool = False,
    topological_relationship: Literal["CONTAINS", "COVERS", "INTERSECTS", "TOUCHES", "WITHIN"] = "CONTAINS",
) -> Column:
    if topological_relationship not in _PRECISE_TOPOLOGICAL_RELATIONSHIPS:
        raise InvalidParameterError(
            f"'topological_relationship' must be one of {sorted(_PRECISE_TOPOLOGICAL_RELATIONSHIPS)}, got '{topological_relationship}'."
        )

    col_str_norm, col_expr_str, col_expr = get_normalized_column_and_expr(column)

    col_geom = F.call_function("try_to_geometry", col_expr) if convert_column else col_expr
    ref_col = reference_geometry if isinstance(reference_geometry, Column) else F.lit(reference_geometry)
    ref_geom = F.call_function("try_to_geometry", ref_col) if convert_reference_geometry else ref_col

    has_relationship = F.call_function(_PRECISE_TOPOLOGICAL_FUNCS[topological_relationship], ref_geom, col_geom)
    condition = F.when(col_expr.isNull(), F.lit(None)).otherwise(~has_relationship)
    text_value_col = F.call_function("st_astext", F.call_function("try_to_geometry", col_expr))

    alias_suffix = _PRECISE_ALIAS_SUFFIX[topological_relationship]
    alias = f'{col_str_norm}_{alias_suffix}'

    message_suffix = _PRECISE_MESSAGE_SUFFIX[topological_relationship]

    return make_condition(
        condition,
        F.concat_ws(
            "",
            F.lit("value `"),
            text_value_col,
            F.lit(f"` in column `{col_expr_str}` {message_suffix}"),
        ),
        alias=alias,
    )


def _has_topological_relationship_approximate(
    column: str | Column,
    reference_geometry: str | Column,
    resolution: int | Column,
    topological_relationship: Literal["COVERS", "INTERSECTS"] = "COVERS",
) -> Column:
    if not (isinstance(resolution, Column) or (isinstance(resolution, int) and 0 <= resolution <= 15)):
        raise InvalidParameterError("'resolution' must be between 0 and 15.")

    if topological_relationship not in _APPROXIMATE_TOPOLOGICAL_RELATIONSHIPS:
        raise InvalidParameterError(
            f"'topological_relationship' must be one of {sorted(_APPROXIMATE_TOPOLOGICAL_RELATIONSHIPS)}, got '{topological_relationship}'."
        )

    col_str_norm, col_expr_str, col_expr = get_normalized_column_and_expr(column)
    ref_col = reference_geometry if isinstance(reference_geometry, Column) else F.lit(reference_geometry)
    resolution_col = resolution if isinstance(resolution, Column) else F.lit(resolution)

    def _h3_cells(geom_expr: Column) -> Column:
        # `h3_try_coverash3` returns NULL for point geometries (no areal coverage) and for
        # invalid/unsupported input. For points we fall back to `h3_pointash3`, but that is the
        # non-`try` variant and raises on non-point/invalid input, so gate it on the value actually
        # parsing to a point. `coalesce` and `when` both short-circuit, so `h3_pointash3` only runs on
        # a confirmed point; invalid geometries yield NULL and are skipped instead of failing the job.
        cover = F.call_function("h3_try_coverash3", geom_expr, resolution_col)
        is_point_geom = F.call_function("st_geometrytype", F.call_function("try_to_geometry", geom_expr)) == F.lit(
            POINT_TYPE
        )
        point_cell = F.when(is_point_geom, F.array(F.call_function("h3_pointash3", geom_expr, resolution_col)))
        return F.array_distinct(F.coalesce(cover, point_cell))

    col_h3_array = _h3_cells(col_expr)
    ref_h3_array = _h3_cells(ref_col)
    intersection_size = F.size(F.array_intersect(col_h3_array, ref_h3_array))

    is_inside = None
    match topological_relationship:
        case "INTERSECTS":
            is_inside = intersection_size > 0
        case "COVERS":
            is_inside = intersection_size == F.size(col_h3_array)
        case _:
            raise InvalidParameterError(f"Unsupported approximate relationship: {topological_relationship!r}")

    condition = F.when(col_expr.isNull() | col_h3_array.isNull(), F.lit(None)).otherwise(~is_inside)

    text_value_col = F.call_function("st_astext", F.call_function("try_to_geometry", col_expr))

    alias_suffix = _APPROXIMATE_ALIAS_SUFFIX[topological_relationship]
    alias = f'{col_str_norm}_{alias_suffix}'

    message_suffix = _APPROXIMATE_MESSAGE_SUFFIX[topological_relationship]

    return make_condition(
        condition,
        F.concat_ws(
            "",
            F.lit("value `"),
            text_value_col,
            F.lit(f"` in column `{col_expr_str}` {message_suffix}"),
        ),
        alias=alias,
    )


@requires_dbr_version("17.1")
@register_rule("row")
def is_geo_contains(
    column: str | Column,
    reference_geometry: str | bytes | Column,
    convert_column: bool = False,
    convert_reference_geometry: bool = False,
) -> Column:
    """Checks if the reference geometry contains the column geometry using `st_contains` with meter-level precision.

    A geometry A *contains* geometry B when B lies entirely within the interior of A, with no boundary
    points of B lying on the boundary of A. Points on the shared boundary are not considered contained;
    use *is_geo_covers* for boundary-inclusive coverage checks.

    Both the target column and the reference geometry are always handled as `GEOMETRY`.
    When conversion is requested (*convert_column* or *convert_reference_geometry* set to True),
    *try_to_geometry* is applied to parse the value from any supported format (WKT, WKB, EWKT, EWKB).
    See https://docs.databricks.com/aws/en/sql/language-manual/functions/try_to_geometry for details.
    When conversion is not requested, the input is assumed to already hold a native `GEOMETRY` value.

    Args:
        column: Column to check. Null values are skipped for validation.
        reference_geometry: Reference geometry as a literal WKT/WKB/EWKT/EWKB string or bytes value,
            or a Column expression (e.g. *F.col('col_name')*) to reference another column. A plain
            string is always treated as a literal, not a column name.
        convert_column: When True, *try_to_geometry* is applied to convert the column values to GEOMETRY.
            When False (default), the column is assumed to already hold a native GEOMETRY value.
        convert_reference_geometry: When True, *try_to_geometry* is applied to convert the reference
            geometry to GEOMETRY. When False (default), the reference geometry is assumed to already
            hold a native GEOMETRY value.

    Returns:
        Column object indicating whether values in the input column are not contained by the reference
        geometry.

    Note:
        This function requires Databricks serverless compute or runtime 17.1 or above.
    """
    return _has_topological_relationship_precise(
        column, reference_geometry, convert_column, convert_reference_geometry, "CONTAINS"
    )


@requires_dbr_version("17.1")
@register_rule("row")
def is_geo_covers(
    column: str | Column,
    reference_geometry: str | bytes | Column,
    precise: bool = False,
    resolution: int | Column | None = None,
    convert_column: bool = False,
    convert_reference_geometry: bool = False,
) -> Column:
    """Checks if the reference geometry covers the column geometry.

    When *precise* is True, uses `st_covers` for exact computation with meter-level precision.
    A geometry A *covers* geometry B when every point of B lies within A, including boundary points.
    This differs from `st_contains`, which excludes points on A's boundary.

    When *precise* is False (default), approximates coverage using H3 cell indexing: all hexagonal
    cells that represent the column geometry must also be present in the H3 cells of the reference
    geometry. Higher *resolution* values give finer precision at the cost of more cells. Because H3
    cells are discrete approximations, boundary behaviour differs from the exact `st_covers` predicate
    and geometries near the boundary may be misclassified.

    Both the target column and the reference geometry are always handled as `GEOMETRY` in precise mode.
    When conversion is requested (*convert_column* or *convert_reference_geometry* set to True),
    *try_to_geometry* is applied. These flags are ignored in approximate mode, where null and invalid
    (unparseable) geometries are skipped rather than flagged — use *is_geometry* to flag invalid values.

    Args:
        column: Column to check. Null values are skipped for validation.
        reference_geometry: Reference geometry as a literal WKT/WKB/EWKT/EWKB string or bytes value,
            or a Column expression (e.g. *F.col('col_name')*) to reference another column. A plain
            string is always treated as a literal, not a column name. Bytes (WKB) are only supported
            in precise mode.
        precise: When True, uses exact `st_covers` computation. When False (default), uses the H3
            approximate method which requires *resolution*.
        resolution: H3 resolution integer (0–15) or column reference. Required when *precise* is False.
            Higher values give finer precision at the cost of more cells.
        convert_column: When True, *try_to_geometry* is applied to convert column values to GEOMETRY.
            Only used in precise mode.
        convert_reference_geometry: When True, *try_to_geometry* is applied to convert the reference
            geometry to GEOMETRY. Only used in precise mode.

    Returns:
        Column object indicating whether values in the input column are not covered by the reference
        geometry.

    Raises:
        InvalidParameterError: If *precise* is False and *resolution* is not provided or is outside 0–15.

    Note:
        This function requires Databricks serverless compute or runtime 17.1 or above if `precise` is True.
    """
    if precise:
        return _has_topological_relationship_precise(
            column, reference_geometry, convert_column, convert_reference_geometry, "COVERS"
        )
    if resolution is None:
        raise InvalidParameterError("'resolution' is required when 'precise' is False.")
    if isinstance(reference_geometry, bytes):
        raise InvalidParameterError("Bytes (WKB) reference geometry is only supported in precise mode.")
    return _has_topological_relationship_approximate(column, reference_geometry, resolution, "COVERS")


@requires_dbr_version("17.1")
@register_rule("row")
def is_geo_intersects(
    column: str | Column,
    reference_geometry: str | bytes | Column,
    precise: bool = False,
    resolution: int | Column | None = None,
    convert_column: bool = False,
    convert_reference_geometry: bool = False,
) -> Column:
    """Checks if the column geometry intersects the reference geometry.

    When *precise* is True, uses `st_intersects` for exact computation with meter-level precision.
    Two geometries intersect when they share at least one point, whether interior or boundary.

    When *precise* is False (default), approximates intersection using H3 cell indexing: at least one
    hexagonal cell must be shared between the H3 representations of the column and reference geometries.
    Higher *resolution* values give finer precision at the cost of more cells. Because H3 cells are
    discrete approximations, boundary behaviour differs from the exact `st_intersects` predicate.

    Both the target column and the reference geometry are always handled as `GEOMETRY` in precise mode.
    When conversion is requested (*convert_column* or *convert_reference_geometry* set to True),
    *try_to_geometry* is applied. These flags are ignored in approximate mode, where null and invalid
    (unparseable) geometries are skipped rather than flagged — use *is_geometry* to flag invalid values.

    Args:
        column: Column to check. Null values are skipped for validation.
        reference_geometry: Reference geometry as a literal WKT/WKB/EWKT/EWKB string or bytes value,
            or a Column expression (e.g. *F.col('col_name')*) to reference another column. A plain
            string is always treated as a literal, not a column name. Bytes (WKB) are only supported
            in precise mode.
        precise: When True, uses exact `st_intersects` computation. When False (default), uses the H3
            approximate method which requires *resolution*.
        resolution: H3 resolution integer (0–15) or column reference. Required when *precise* is False.
            Higher values give finer precision at the cost of more cells.
        convert_column: When True, *try_to_geometry* is applied to convert column values to GEOMETRY.
            Only used in precise mode.
        convert_reference_geometry: When True, *try_to_geometry* is applied to convert the reference
            geometry to GEOMETRY. Only used in precise mode.

    Returns:
        Column object indicating whether values in the input column do not intersect the reference
        geometry.

    Raises:
        InvalidParameterError: If *precise* is False and *resolution* is not provided or is outside 0–15.

    Note:
        This function requires Databricks serverless compute or runtime 17.1 or above if `precise` is True.
    """
    if precise:
        return _has_topological_relationship_precise(
            column, reference_geometry, convert_column, convert_reference_geometry, "INTERSECTS"
        )
    if resolution is None:
        raise InvalidParameterError("'resolution' is required when 'precise' is False.")
    if isinstance(reference_geometry, bytes):
        raise InvalidParameterError("Bytes (WKB) reference geometry is only supported in precise mode.")
    return _has_topological_relationship_approximate(column, reference_geometry, resolution, "INTERSECTS")


@requires_dbr_version("17.1")
@register_rule("row")
def is_geo_touches(
    column: str | Column,
    reference_geometry: str | bytes | Column,
    convert_column: bool = False,
    convert_reference_geometry: bool = False,
) -> Column:
    """Checks if the column geometry touches the reference geometry using `st_touches` with meter-level precision.

    Two geometries *touch* when they share at least one boundary point but their interiors do not
    intersect. A point strictly inside a polygon does not touch it; a point on the polygon boundary
    does.

    Both the target column and the reference geometry are always handled as `GEOMETRY`.
    When conversion is requested (*convert_column* or *convert_reference_geometry* set to True),
    *try_to_geometry* is applied to parse the value from any supported format (WKT, WKB, EWKT, EWKB).
    When conversion is not requested, the input is assumed to already hold a native `GEOMETRY` value.

    Args:
        column: Column to check. Null values are skipped for validation.
        reference_geometry: Reference geometry as a literal WKT/WKB/EWKT/EWKB string or bytes value,
            or a Column expression (e.g. *F.col('col_name')*) to reference another column. A plain
            string is always treated as a literal, not a column name.
        convert_column: When True, *try_to_geometry* is applied to convert column values to GEOMETRY.
            When False (default), the column is assumed to already hold a native GEOMETRY value.
        convert_reference_geometry: When True, *try_to_geometry* is applied to convert the reference
            geometry to GEOMETRY. When False (default), the reference geometry is assumed to already
            hold a native GEOMETRY value.

    Returns:
        Column object indicating whether values in the input column do not touch the reference geometry.

    Note:
        This function requires Databricks serverless compute or runtime 17.1 or above.
    """
    return _has_topological_relationship_precise(
        column, reference_geometry, convert_column, convert_reference_geometry, "TOUCHES"
    )


@requires_dbr_version("17.1")
@register_rule("row")
def is_geo_within(
    column: str | Column,
    reference_geometry: str | bytes | Column,
    convert_column: bool = False,
    convert_reference_geometry: bool = False,
) -> Column:
    """Checks if the reference geometry is within the column geometry using `st_within` with meter-level precision.

    *NOTE*: the column geometry is the OUTER container in this check; the reference is the inner test geometry.
    Contrast with is_geo_contains where the reference is the outer container.

    `st_within(reference, column)` returns true when the reference geometry lies entirely within the
    column geometry. This is the converse of `st_contains`: the column geometry must contain the
    reference, with the reference's boundary and interior both lying inside the column's interior.

    Both the target column and the reference geometry are always handled as `GEOMETRY`.
    When conversion is requested (*convert_column* or *convert_reference_geometry* set to True),
    *try_to_geometry* is applied to parse the value from any supported format (WKT, WKB, EWKT, EWKB).
    When conversion is not requested, the input is assumed to already hold a native `GEOMETRY` value.

    Args:
        column: Column to check. Null values are skipped for validation.
        reference_geometry: Reference geometry as a literal WKT/WKB/EWKT/EWKB string or bytes value,
            or a Column expression (e.g. *F.col('col_name')*) to reference another column. A plain
            string is always treated as a literal, not a column name.
        convert_column: When True, *try_to_geometry* is applied to convert column values to GEOMETRY.
            When False (default), the column is assumed to already hold a native GEOMETRY value.
        convert_reference_geometry: When True, *try_to_geometry* is applied to convert the reference
            geometry to GEOMETRY. When False (default), the reference geometry is assumed to already
            hold a native GEOMETRY value.

    Returns:
        Column object indicating whether the reference geometry is not within the values in the input
        column.

    Note:
        This function requires Databricks serverless compute or runtime 17.1 or above.
    """
    return _has_topological_relationship_precise(
        column, reference_geometry, convert_column, convert_reference_geometry, "WITHIN"
    )
