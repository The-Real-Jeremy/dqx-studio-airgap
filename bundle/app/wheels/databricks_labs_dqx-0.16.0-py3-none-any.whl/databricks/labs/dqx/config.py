import re
from abc import ABC
from dataclasses import asdict, dataclass, field
from typing import Any

from pydantic import BaseModel, ConfigDict, ValidationError, model_validator

from databricks.labs.dqx.checks_serializer import SerializerFactory
from databricks.labs.dqx.errors import InvalidConfigError, InvalidParameterError
from databricks.labs.dqx.utils import VariableValue

__all__ = [
    "WorkspaceConfig",
    "RunConfig",
    "InputConfig",
    "OutputConfig",
    "ExtraParams",
    "ProfilerConfig",
    "LLMModelConfig",
    "LLMConfig",
    "AnomalyConfig",
    "AnomalyParams",
    "IsolationForestConfig",
    "FeatureEngineeringConfig",
    "TemporalAnomalyConfig",
    "BaseChecksStorageConfig",
    "FileChecksStorageConfig",
    "WorkspaceFileChecksStorageConfig",
    "TableChecksStorageConfig",
    "LakebaseChecksStorageConfig",
    "InstallationChecksStorageConfig",
    "VolumeFileChecksStorageConfig",
    "DQSecret",
    "TableActionsStorageConfig",
    "LakebaseActionsStorageConfig",
    "ActionEventsConfig",
]


@dataclass(frozen=True)
class DQSecret:
    """A reference to a Databricks secret stored in a secret scope.

    Provides a canonical *scope/key* string representation that can be passed as
    a credential reference in DQX configuration without embedding the secret
    value in plain text.

    Resolves against **classic Databricks workspace secret scopes** (the
    *dbutils.secrets* / Secrets API), **not** Unity Catalog secrets. The value is
    read at delivery time from the workspace that the engine's *WorkspaceClient*
    targets, so the scope and key must exist in that same workspace.

    Args:
        scope: The Databricks secret scope name.
        key: The key within the secret scope.
    """

    scope: str
    key: str

    def as_reference(self) -> str:
        """Return the canonical *scope/key* reference string.

        Returns:
            A string of the form ``scope/key``.
        """
        return f"{self.scope}/{self.key}"

    @classmethod
    def from_reference(cls, ref: str) -> "DQSecret":
        """Parse a *scope/key* reference string into a *DQSecret*.

        The string is split on the **first** ``/`` only, so a key that itself
        contains slashes is handled correctly.

        Args:
            ref: A reference string in the form ``scope/key``.

        Returns:
            A new *DQSecret* instance.

        Raises:
            InvalidParameterError: If *ref* does not contain a ``/``, or if
                either the scope or key part is empty.
        """
        if "/" not in ref:
            raise InvalidParameterError(f"Secret reference must be in the form 'scope/key', got {ref!r}.")
        raw_scope, _, raw_key = ref.partition("/")
        scope = raw_scope.strip()
        key = raw_key.strip()
        if not scope or not key:
            raise InvalidParameterError(f"Secret reference must have non-empty scope and key parts, got {ref!r}.")
        return cls(scope=scope, key=key)


@dataclass
class InputConfig:
    """Configuration class for input data sources (e.g. tables or files)."""

    location: str
    format: str = "delta"
    is_streaming: bool = False
    schema: str | None = None
    options: dict[str, str] = field(default_factory=dict)


@dataclass
class OutputConfig:
    """Configuration class for output data sinks (e.g. tables or files)."""

    location: str
    format: str = "delta"
    mode: str = "append"
    options: dict[str, str] = field(default_factory=dict)
    trigger: dict[str, str | bool] = field(default_factory=dict)
    partition_by: list[str] = field(default_factory=list)
    cluster_by: list[str] = field(default_factory=list)

    def __post_init__(self):
        """
        Normalize trigger configuration by converting string boolean representations to actual booleans.
        This is required due to the limitation of the config deserializer.
        """
        if self.partition_by and self.cluster_by:
            raise InvalidParameterError("Only one of partition_by or cluster_by is allowed")
        # Convert string representations of booleans to actual booleans
        for key, value in list(self.trigger.items()):
            if isinstance(value, str):
                if value.lower() == 'true':
                    self.trigger[key] = True
                elif value.lower() == 'false':
                    self.trigger[key] = False
                # Otherwise keep it as a string (e.g., "10 seconds" for processingTime)


@dataclass
class ProfilerConfig:
    """Configuration class for profiler."""

    summary_stats_file: str = "profile_summary_stats.yml"  # file containing profile summary statistics
    # fraction of data to sample; can be a uniform proportion or a mapping of
    # sample_by_column values to their respective proportions
    sample_fraction: float | dict[object, float] | None = 0.3
    sample_seed: int | None = None  # seed for sampling
    sample_by_column: str | None = None  # column with keys to sample by
    sample_by_values_limit: int = 1000  # max distinct sample_by_column values to collect when sampling uniformly
    limit: int = 1000  # limit the number of records to profile
    filter: str | None = None  # filter to apply to the data before profiling
    criticality: str = "error"  # default criticality for generated rules ("error" or "warn")
    llm_primary_key_detection: bool = (
        False  # whether to use LLM for primary key detection to generate uniqueness checks
    )
    # Override profiler default thresholds
    max_null_ratio: float | None = None
    max_empty_ratio: float | None = None
    outliers_ratio: float | None = None


@dataclass
class IsolationForestConfig:
    """Algorithm parameters for Spark ML IsolationForest."""

    contamination: float | None = None
    num_trees: int = 200
    max_depth: int | None = None
    subsampling_rate: float | None = None
    random_seed: int = 42


@dataclass
class TemporalAnomalyConfig:
    """Configuration for temporal feature extraction."""

    timestamp_column: str
    temporal_features: list[str] = field(default_factory=lambda: ["hour", "day_of_week", "month"])


@dataclass
class FeatureEngineeringConfig:
    """Configuration for multi-type feature engineering in anomaly detection."""

    max_input_columns: int = 25  # Soft limit - warns but proceeds if exceeded
    max_engineered_features: int = 50  # Soft limit on total engineered features
    categorical_cardinality_threshold: int = 20  # OneHot if <=20, Frequency if >20
    # Datetime features (always 7 per column: hour_sin, hour_cos, dow_sin, dow_cos, month_sin, month_cos, is_weekend)
    datetime_features: list[str] = field(
        default_factory=lambda: ["hour_sin", "hour_cos", "dow_sin", "dow_cos", "month_sin", "month_cos", "is_weekend"]
    )
    enable_categorical: bool = True
    enable_datetime: bool = True
    enable_boolean: bool = True


@dataclass
class AnomalyParams:
    """Optional tuning parameters for row anomaly detection.

    Attributes:
        sample_fraction: Fraction of data to sample for training (default 0.3).
        max_rows: Maximum rows to use for training (default 1,000,000).
        train_ratio: Train/validation split ratio (default 0.8).
        ensemble_size: Number of models in ensemble (default 3). Set to None for single model.
            Ensemble models provide:
            - More robust anomaly scores (averaged across models)
            - Confidence scores via standard deviation
            - Better generalization
            Performance: Optimized ensemble scoring makes this negligible overhead.
        algorithm_config: Isolation Forest parameters (contamination, num_trees, seed).
        feature_engineering: Feature engineering parameters (temporal features, scaling, etc.).
    """

    sample_fraction: float = 0.3
    max_rows: int = 1_000_000
    train_ratio: float = 0.8
    ensemble_size: int | None = 3  # Default 3-model ensemble for robustness, tie-breaking, and confidence scores
    algorithm_config: IsolationForestConfig = field(default_factory=IsolationForestConfig)
    feature_engineering: FeatureEngineeringConfig = field(default_factory=FeatureEngineeringConfig)


@dataclass
class AnomalyConfig:
    """Configuration for row anomaly detection."""

    columns: list[str] | None = None  # Auto-discovered if omitted
    segment_by: list[str] | None = None  # Auto-discovered if omitted (when columns also omitted)
    model_name: str | None = None  # Optional in workflows; defaults to dqx_anomaly_<run_config.name>
    registry_table: str | None = None


@dataclass
class RunConfig:
    """Configuration class for the data quality checks"""

    name: str = "default"  # name of the run configuration
    input_config: InputConfig | None = None
    output_config: OutputConfig | None = None
    quarantine_config: OutputConfig | None = None  # quarantined data table
    metrics_config: OutputConfig | None = None  # summary metrics table
    profiler_config: ProfilerConfig = field(default_factory=ProfilerConfig)
    checks_user_requirements: str | None = None  # user input for AI-assisted rule generation

    checks_location: str = (
        "checks.yml"  # absolute or relative workspace file path or table containing quality rules / checks
    )

    warehouse_id: str | None = None  # warehouse id to use in the dashboard

    reference_tables: dict[str, InputConfig] = field(default_factory=dict)  # reference tables to use in the checks
    # mapping of fully qualified custom check function (e.g. my_func) to the module location in the workspace
    # (e.g. {"my_func": "/Workspace/my_repo/my_module.py"})
    custom_check_functions: dict[str, str] = field(default_factory=dict)

    anomaly_config: AnomalyConfig | None = None  # optional anomaly detection configuration

    # Lakebase connection parameters, if wanting to store checks in lakebase database
    lakebase_instance_name: str | None = None
    lakebase_client_id: str | None = None
    lakebase_port: str | None = None

    # UC/Lakebase table (or workspace/volume file) holding action definitions to auto-load and apply
    # during workflow runs. None disables actions for this run config.
    actions_location: str | None = None
    # UC/Lakebase table for action event history and durable alert suppression across runs.
    # None keeps alert suppression state in-memory only (resets each run).
    action_events_location: str | None = None


@dataclass
class LLMModelConfig:
    """Configuration for LLM model"""

    # The model to use. For AI explanations this resolves to a Databricks Model Serving endpoint
    # name (the ``databricks/`` provider prefix, if present, is stripped before the ai_query call).
    model_name: str = "databricks/databricks-claude-sonnet-4-5"
    # Optional API key for the model as text or secret scope/key. Not required by foundational models.
    api_key: str = ""  # when used with Profiler Workflow, this should be a secret: secret_scope/secret_key
    # Optional API base URL for the model. Not required by foundational models. Used by the LLM
    # rule-generation / profiler path; the anomaly AI-explanation path runs via Spark SQL
    # ``ai_query`` against a Databricks Model Serving endpoint resolved from *model_name* and does
    # not use *api_base*. When used with Profiler Workflow, this can be a secret scope/key reference.
    #
    # This URL is passed to the outbound LLM client (litellm via DSPy) on
    # the rule-generation path, so it must be a trusted, admin-controlled endpoint — a Databricks
    # Model Serving / AI Gateway URL or a known OpenAI-compatible host — supplied via deployment
    # config or a secret reference. Do NOT populate it from untrusted or end-user input, and do not
    # point it at arbitrary internal hosts; doing so lets the profiler job issue requests to that
    # target. Prefer HTTPS endpoints.
    api_base: str = ""
    # Per-call output token cap. Bounds cost and latency for pathological prompts (OWASP LLM04).
    max_tokens: int = 1000
    # Sampling temperature. 0.0 is deterministic; raise for more creative narratives.
    temperature: float = 0.0
    # Per-call wall-clock timeout in seconds.
    timeout: float = 30.0
    # Number of retries on transient LLM-call failures (used by the LLM rule-generation path). The
    # AI-explanation path runs through Spark SQL ``ai_query`` against Databricks Model Serving, which
    # handles retries internally and does not expose the count.
    max_retries: int = 3

    def __post_init__(self) -> None:
        if not isinstance(self.max_retries, int) or isinstance(self.max_retries, bool) or self.max_retries < 0:
            raise InvalidParameterError(f"max_retries must be a non-negative integer, got {self.max_retries!r}")
        if not isinstance(self.max_tokens, int) or isinstance(self.max_tokens, bool) or self.max_tokens <= 0:
            raise InvalidParameterError(f"max_tokens must be a positive integer, got {self.max_tokens!r}")
        if not isinstance(self.temperature, (int, float)) or isinstance(self.temperature, bool) or self.temperature < 0:
            raise InvalidParameterError(f"temperature must be a non-negative number, got {self.temperature!r}")


@dataclass(frozen=True)
class LLMConfig:
    """Configuration for LLM usage"""

    model: LLMModelConfig = field(default_factory=LLMModelConfig)


@dataclass(frozen=True)
class ExtraParams:
    """Class to represent extra parameters for DQEngine."""

    result_column_names: dict[str, str] = field(default_factory=dict)
    user_metadata: dict[str, str] = field(default_factory=dict)
    run_time_overwrite: str | None = None
    run_id_overwrite: str | None = None
    suppress_skipped: bool = False
    variables: dict[str, VariableValue] = field(default_factory=dict)


@dataclass
class WorkspaceConfig:
    """Configuration class for the workspace"""

    __file__ = "config.yml"
    __version__ = 1

    run_configs: list[RunConfig]
    log_level: str | None = "INFO"

    # whether to use serverless clusters for the jobs, only used during workspace installation
    serverless_clusters: bool = True
    upload_dependencies: bool = (
        False  # whether to upload dependencies to the workspace during installation to enable DQX in restricted (no-internet) environments
    )
    extra_params: ExtraParams | None = None  # extra parameters to pass to the jobs, e.g. result_column_names

    # cluster configuration for the jobs (applicable for non-serverless clusters only)
    profiler_override_clusters: dict[str, str] | None = field(default_factory=dict)
    quality_checker_override_clusters: dict[str, str] | None = field(default_factory=dict)
    e2e_override_clusters: dict[str, str] | None = field(default_factory=dict)
    anomaly_override_clusters: dict[str, str] | None = field(default_factory=dict)

    # extra spark config for jobs (applicable for non-serverless clusters only)
    profiler_spark_conf: dict[str, str] | None = field(default_factory=dict)
    quality_checker_spark_conf: dict[str, str] | None = field(default_factory=dict)
    e2e_spark_conf: dict[str, str] | None = field(default_factory=dict)
    anomaly_spark_conf: dict[str, str] | None = field(default_factory=dict)

    profiler_max_parallelism: int = 4  # max parallelism for profiling multiple tables
    quality_checker_max_parallelism: int = 4  # max parallelism for quality checking multiple tables
    custom_metrics: list[str] | None = None  # custom summary metrics tracked by the observer when applying checks

    llm_config: LLMConfig = field(default_factory=LLMConfig)

    def as_dict(self) -> dict:
        """
        Convert the WorkspaceConfig to a dictionary for serialization.
        This method ensures that all fields, including boolean False values, are properly serialized.
        Used by blueprint's installation when saving the config (Installation.save()).

        Returns:
            A dictionary representation of the WorkspaceConfig.
        """
        return asdict(self)

    def get_run_config(self, run_config_name: str | None = "default") -> RunConfig:
        """Get the run configuration for a given run name, or the default configuration if no run name is provided.

        Args:
            run_config_name: The name of the run configuration to get, e.g. input table or job name (use "default" if not provided).

        Returns:
            The run configuration.

        Raises:
            InvalidConfigError: If no run configurations are available or if the specified run configuration name is
            not found.
        """
        if not self.run_configs:
            raise InvalidConfigError("No run configurations available")

        if not run_config_name:
            return self.run_configs[0]

        for run in self.run_configs:
            if run.name == run_config_name:
                return run

        raise InvalidConfigError("No run configurations available")


# Matches a two- or three-part table identifier (optional catalog), each part a bare or
# backtick-quoted name: e.g. catalog.schema.table, schema.table, cat.sch.`weird.name`.
# Databricks permits leading digits in unquoted identifiers (e.g. `1abc` is a valid table name;
# verified against a live workspace), so a bare part is [a-zA-Z0-9_]+; special characters must be
# backtick-quoted.
_IDENT = r"(?:`[^`]+`|[a-zA-Z0-9_]+)"
TABLE_PATTERN = re.compile(rf"^(?:{_IDENT}\.)?{_IDENT}\.{_IDENT}$")
# A three-part table identifier only (catalog.schema.table), i.e. a namespace resolvable through the
# Unity Catalog tables API. Unlike TABLE_PATTERN, the catalog part is required.
UC_TABLE_PATTERN = re.compile(rf"^{_IDENT}\.{_IDENT}\.{_IDENT}$")


def is_table_location(location: str) -> bool:
    """Return True if *location* is a Delta table name (catalog.schema.table), not a file path.

    A location is a table when it matches the table-identifier pattern AND does not end with a known
    checks-serializer file extension (.json/.yml/...). This is the single source of truth for the
    table-vs-file distinction; *io.py* and *checks_storage.py* re-export it.

    Args:
        location: The location string to classify.

    Returns:
        True if *location* names a table, False if it is a file path or otherwise not a table.
    """
    return bool(TABLE_PATTERN.match(location)) and not location.lower().endswith(
        SerializerFactory.get_supported_extensions()
    )


def _is_three_part_table_location(location: str) -> bool:
    """Return True if *location* is a table (not a file) with an exact three-part name.

    Stricter than *is_table_location* (which also accepts the two-part *schema.table* form): Lakebase
    requires a fully qualified *database.schema.table*.
    """
    return is_table_location(location) and len(location.split(".")) == 3


class BaseChecksStorageConfig(BaseModel, ABC):
    """Marker base class for storage configuration.

    Args:
        location: The file path or table name where checks are stored.
    """

    model_config = ConfigDict(extra="forbid")

    location: str

    def __init__(self, **data: Any) -> None:
        try:
            super().__init__(**data)
        except ValidationError as exc:
            raise InvalidConfigError(str(exc)) from exc

    def replace(self, **changes: Any) -> "BaseChecksStorageConfig":
        """Return a new config instance with the given field overrides, fully re-validated.

        Unlike *model_copy(update=...)*, which shallow-copies the instance and skips all
        validators, this rebuilds the config through the constructor so the *model_validator*
        checks (e.g. *mode* and *location* format) re-run against the updated fields. Use this
        instead of *model_copy* when overriding fields, so an invalid override is rejected at
        the point of the change rather than failing later during a save/load operation.

        Args:
            **changes: Field values to override on the new instance.

        Returns:
            A new, fully validated config of the same concrete type.
        """
        fields = {name: getattr(self, name) for name in type(self).model_fields}
        fields.update(changes)
        return type(self)(**fields)


class FileChecksStorageConfig(BaseChecksStorageConfig):
    """
    Configuration class for storing checks in a file.

    Args:
        location: The file path where the checks are stored.
    """

    @model_validator(mode='before')
    @classmethod
    def validate_location(cls, data: Any) -> Any:
        # `cls is FileChecksStorageConfig` intentionally excludes subclasses.
        # InstallationChecksStorageConfig uses diamond inheritance from this class and
        # WorkspaceFileChecksStorageConfig; both validators are inherited and would fire
        # for any subclass without the exact-class guard, giving confusing duplicate errors.
        # InstallationChecksStorageConfig has its own validate_installation_location that
        # covers the empty-location case for itself.
        if cls is FileChecksStorageConfig and isinstance(data, dict) and not data.get("location"):
            raise InvalidConfigError("The file path ('location' field) must not be empty or None.")
        return data


class WorkspaceFileChecksStorageConfig(BaseChecksStorageConfig):
    """
    Configuration class for storing checks in a workspace file.

    Args:
        location: The workspace file path where the checks are stored.
    """

    @model_validator(mode='before')
    @classmethod
    def validate_location(cls, data: Any) -> Any:
        # See FileChecksStorageConfig.validate_location for why the exact-class guard is needed.
        if cls is WorkspaceFileChecksStorageConfig and isinstance(data, dict) and not data.get("location"):
            raise InvalidConfigError("The workspace file path ('location' field) must not be empty or None.")
        return data


class TableChecksStorageConfig(BaseChecksStorageConfig):
    """
    Configuration class for storing checks in a table.

    Args:
        location: The table name where the checks are stored.
        run_config_name: The name of the run configuration to use for checks, e.g. input table or job name (use "default" if not provided).
        mode: The mode for writing checks to a table ('append' or 'overwrite', default 'append').
            - **overwrite**: Replaces all rows for this run_config_name when the fingerprint differs.
              Skips write when the fingerprint already exists.
            - **append**: Adds new rows when the fingerprint differs; multiple versions can coexist.
              Skips write when the fingerprint already exists.
        rule_set_fingerprint: Optional SHA-256 fingerprint of the rule set to load.
            When provided, loads rules matching this specific fingerprint instead of the latest batch.
            When None (default), loads the latest batch.
    """

    run_config_name: str = "default"  # to filter checks by run config
    mode: str = "append"
    rule_set_fingerprint: str | None = None  # to filter checks by rule set fingerprint

    @model_validator(mode='before')
    @classmethod
    def validate_location(cls, data: Any) -> Any:
        # See FileChecksStorageConfig.validate_location for why the exact-class guard is needed.
        if cls is TableChecksStorageConfig and isinstance(data, dict) and not data.get("location"):
            raise InvalidConfigError("The table name ('location' field) must not be empty or None.")
        return data


class LakebaseChecksStorageConfig(BaseChecksStorageConfig):
    """
    Configuration class for storing checks in a Lakebase table.

    Args:
        location: Fully qualified name of the Lakebase table to store checks in the format 'database.schema.table'.
        instance_name: Name of the Lakebase instance.
        client_id: ID of the Databricks service principal to use for the Lakebase connection.
        port: The Lakebase port (default is '5432').
        run_config_name: Name of the run configuration to use for checks (default is 'default').
        mode: The mode for writing checks to a table ('append' or 'overwrite', default 'append').
            - **overwrite**: Replaces all rows for this run_config_name when the fingerprint differs.
              Skips write when the fingerprint already exists.
            - **append**: Adds new rows when the fingerprint differs; multiple versions can coexist.
              Skips write when the fingerprint already exists.
        rule_set_fingerprint: Optional SHA-256 fingerprint of the rule set to load.
            When provided, loads rules matching this specific fingerprint instead of the latest batch.
            When None (default), loads the latest batch.
    """

    instance_name: str | None = None
    client_id: str | None = None
    port: str = "5432"
    run_config_name: str = "default"
    mode: str = "append"
    rule_set_fingerprint: str | None = None

    @model_validator(mode='before')
    @classmethod
    def validate_location_present(cls, data: Any) -> Any:
        if cls is LakebaseChecksStorageConfig and isinstance(data, dict) and not data.get("location"):
            raise InvalidParameterError("Location must not be empty or None.")
        return data

    @model_validator(mode='after')
    def validate_lakebase_config(self) -> 'LakebaseChecksStorageConfig':
        if self.__class__ is not LakebaseChecksStorageConfig:
            return self

        if not self.instance_name:
            raise InvalidParameterError("Instance name must not be empty or None.")

        # Lakebase requires an exact three-part database.schema.table name that is a table, not a file.
        if not _is_three_part_table_location(self.location):
            raise InvalidConfigError(
                f"Invalid Lakebase table name '{self.location}'. Must be in the format 'database.schema.table'."
            )

        if self.mode not in ("append", "overwrite"):
            raise InvalidConfigError(f"Invalid mode '{self.mode}'. Must be 'append' or 'overwrite'.")

        return self

    def _split_location(self) -> tuple[str, ...]:
        """Splits 'database.schema.table' into components."""
        if not self.location:
            raise InvalidConfigError("location must be set before accessing database components.")
        return tuple(self.location.split("."))

    @property
    def database_name(self) -> str:
        return self._split_location()[0]

    @property
    def schema_name(self) -> str:
        return self._split_location()[1]

    @property
    def table_name(self) -> str:
        return self._split_location()[2]


class VolumeFileChecksStorageConfig(BaseChecksStorageConfig):
    """
    Configuration class for storing checks in a Unity Catalog volume file.

    Args:
        location: The Unity Catalog volume file path where the checks are stored.
    """

    @model_validator(mode='before')
    @classmethod
    def validate_location_present(cls, data: Any) -> Any:
        if cls is VolumeFileChecksStorageConfig and isinstance(data, dict) and not data.get("location"):
            raise InvalidParameterError(
                "The Unity Catalog volume file path ('location' field) must not be empty or None."
            )
        return data

    @model_validator(mode='after')
    def validate_location(self) -> 'VolumeFileChecksStorageConfig':
        if self.__class__ is not VolumeFileChecksStorageConfig:
            return self

        # Expected format: /Volumes/{catalog}/{schema}/{volume}/{path/to/file}
        if not self.location.startswith("/Volumes/"):
            raise InvalidParameterError("The volume path must start with '/Volumes/'.")

        parts = self.location.split("/")
        # After split need at least: ['', 'Volumes', 'catalog', 'schema', 'volume', optional 'dir', 'file']
        if len(parts) < 3 or not parts[2]:
            raise InvalidParameterError("Invalid path: Path is missing a catalog name")
        if len(parts) < 4 or not parts[3]:
            raise InvalidParameterError("Invalid path: Path is missing a schema name")
        if len(parts) < 5 or not parts[4]:
            raise InvalidParameterError("Invalid path: Path is missing a volume name")
        if len(parts) < 6 or not parts[-1].lower().endswith(SerializerFactory.get_supported_extensions()):
            raise InvalidParameterError("Invalid path: Path must include a file name after the volume")

        return self


class InstallationChecksStorageConfig(
    WorkspaceFileChecksStorageConfig,
    TableChecksStorageConfig,
    VolumeFileChecksStorageConfig,
    LakebaseChecksStorageConfig,
):
    """
    Configuration class for storing checks in an installation.

    Args:
        location: The installation path where the checks are stored (e.g., table name, file path).
            Not used when using installation method, as it is retrieved from the installation config,
            unless overwrite_location is enabled.
        run_config_name: The name of the run configuration to use for checks, e.g. input table or job name (use "default" if not provided).
        product_name: The product name for retrieving checks from the installation (default is 'dqx').
        assume_user: Whether to assume the user is the owner of the checks (default is True).
        install_folder: The installation folder where DQX is installed.
        DQX will be installed in a default directory if no custom folder is provided:
        * User's home directory: "/Users/<your_user>/.dqx"
        * Global directory if `DQX_FORCE_INSTALL=global`: "/Applications/dqx"
        overwrite_location: Whether to overwrite the location from run config if provided (default is False).
    """

    location: str = "installation"  # retrieved from the installation config
    run_config_name: str = "default"  # to retrieve run config
    product_name: str = "dqx"
    assume_user: bool = True
    install_folder: str | None = None
    overwrite_location: bool = False

    @model_validator(mode='before')
    @classmethod
    def validate_installation_location(cls, data: Any) -> Any:
        # Only guard against an explicitly empty/None location; an absent key keeps the default above.
        if isinstance(data, dict) and "location" in data and not data["location"]:
            raise InvalidConfigError("The workspace file path ('location' field) must not be empty or None.")
        return data


class TableActionsStorageConfig(BaseChecksStorageConfig):
    """Configuration class for persisting DQ action definitions to a Unity Catalog table.

    Args:
        location: Fully qualified UC table name (e.g. *catalog.schema.table*) where action definitions are stored.
        run_config_name: Name of the run configuration these actions belong to (default is *default*).
        mode: Write mode for the table (*append* or *overwrite*, default *append*).
    """

    run_config_name: str = "default"
    mode: str = "append"

    @model_validator(mode="before")
    @classmethod
    def validate_location(cls, data: Any) -> Any:
        if cls is TableActionsStorageConfig and isinstance(data, dict) and not data.get("location"):
            raise InvalidConfigError("The table name ('location' field) must not be empty or None.")
        return data

    @model_validator(mode="after")
    def validate_mode(self) -> "TableActionsStorageConfig":
        if self.mode not in ("append", "overwrite"):
            raise InvalidConfigError(f"Invalid mode '{self.mode}'. Must be 'append' or 'overwrite'.")
        return self


class LakebaseActionsStorageConfig(BaseChecksStorageConfig):
    """Configuration class for persisting DQ action definitions to a Lakebase (PostgreSQL) table.

    The *location* must be a fully qualified three-part name in the form *database.schema.table*.

    Args:
        location: Fully qualified Lakebase table name in the format *database.schema.table*.
        instance_name: Name of the Lakebase instance.
        client_id: ID of the Databricks service principal for the Lakebase connection.
        port: Lakebase port (default is *5432*).
        run_config_name: Name of the run configuration these actions belong to (default is *default*).
        mode: Write mode for the table (*append* or *overwrite*, default *append*).
    """

    instance_name: str | None = None
    client_id: str | None = None
    port: str = "5432"
    run_config_name: str = "default"
    mode: str = "append"

    @model_validator(mode="before")
    @classmethod
    def validate_location_present(cls, data: Any) -> Any:
        if cls is LakebaseActionsStorageConfig and isinstance(data, dict) and not data.get("location"):
            raise InvalidParameterError("Location must not be empty or None.")
        return data

    @model_validator(mode="after")
    def validate_lakebase_config(self) -> "LakebaseActionsStorageConfig":
        if not self.instance_name:
            raise InvalidParameterError("Instance name must not be empty or None.")

        # Lakebase requires an exact three-part database.schema.table name that is a table, not a file.
        if not _is_three_part_table_location(self.location):
            raise InvalidConfigError(
                f"Invalid Lakebase table name '{self.location}'. Must be in the format 'database.schema.table'."
            )

        if self.mode not in ("append", "overwrite"):
            raise InvalidConfigError(f"Invalid mode '{self.mode}'. Must be 'append' or 'overwrite'.")

        return self

    def _split_location(self) -> tuple[str, ...]:
        """Splits *database.schema.table* into components."""
        return tuple(self.location.split("."))

    @property
    def database_name(self) -> str:
        """The database portion of the three-part location."""
        return self._split_location()[0]

    @property
    def schema_name(self) -> str:
        """The schema portion of the three-part location."""
        return self._split_location()[1]

    @property
    def table_name(self) -> str:
        """The table portion of the three-part location."""
        return self._split_location()[2]


class ActionEventsConfig(BaseChecksStorageConfig):
    """Configuration class for storing DQ action events in a Unity Catalog table.

    Args:
        location: Fully qualified UC table name (e.g. *catalog.schema.events*) where action events are written.
        mode: Reserved for API symmetry with the other storage configs. Action events form an
            append-only audit log, so the events table is always appended to regardless of this value.
        run_config_name: Run configuration the events belong to. Events are stamped with, and loaded
            filtered by, this value so a shared events table keeps per-run-config alert suppression
            independent (default is *default*).
    """

    mode: str = "append"
    run_config_name: str = "default"

    @model_validator(mode="before")
    @classmethod
    def validate_location(cls, data: Any) -> Any:
        if cls is ActionEventsConfig and isinstance(data, dict) and not data.get("location"):
            raise InvalidConfigError("The events table name ('location' field) must not be empty or None.")
        return data

    @model_validator(mode="after")
    def validate_location_is_table(self) -> "ActionEventsConfig":
        # Action events are always written to a Unity Catalog or Lakebase table, never a file. Validate
        # here (at construction) so the guarantee holds regardless of how the config is built, rather
        # than relying on a caller to check the location before constructing it.
        if not is_table_location(self.location):
            raise InvalidConfigError(
                f"action_events_location '{self.location}' must be a Unity Catalog table "
                "(catalog.schema.table) or a Lakebase table; file locations are not supported for action events."
            )
        return self

    @model_validator(mode="after")
    def validate_mode(self) -> "ActionEventsConfig":
        if self.mode not in ("append", "overwrite"):
            raise InvalidConfigError(f"Invalid mode '{self.mode}'. Must be 'append' or 'overwrite'.")
        return self
