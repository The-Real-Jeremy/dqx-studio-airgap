import json
from dataclasses import dataclass
from datetime import datetime
from functools import cached_property
from typing import Any
from uuid import uuid4

from pyspark.sql import DataFrame, Observation, SparkSession
import pyspark.sql.functions as F


OBSERVATION_TABLE_SCHEMA = (
    "run_id string, run_name string, input_location string, output_location string, quarantine_location string, "
    "checks_location string, rule_set_fingerprint string, metric_name string, metric_value string, run_time timestamp, "
    "error_column_name string, warning_column_name string, user_metadata map<string, string>"
)


@dataclass(frozen=True)
class DQMetricsObservation:
    """
    Observer metrics class used to persist summary metrics.

    Args:
        run_id: Unique observation id.
        run_name: Name of the observations, taken from the engine's observer. None when the engine has no
            observer configured (e.g. metrics persisted via save_results_in_table without an observer).
        observed_metrics: Dictionary of observed metrics.
        run_time_overwrite: Run time when the data quality summary metrics were observed. If None, current_timestamp() is used.
        error_column_name: Name of the error column when running quality checks.
        warning_column_name: Name of the warning column when running quality checks.
        input_location: (optional) Location where input data is loaded from when running quality checks (fully-qualified table
            name or file path).
        output_location: (optional) Location where output data is persisted when running quality checks (fully-qualified table
            name or file path).
        quarantine_location: (optional) Location where quarantined data is persisted when running quality checks (fully-qualified
            table name or file path).
        checks_location: (optional) Location where checks are loaded from when running quality checks (fully-qualified table name
            or file path).
        rule_set_fingerprint: (optional) SHA-256 fingerprint of the rule set used for this run. Enables correlation with
            checks storage and filtering metrics by rule set version.
    """

    run_id: str
    run_name: str | None
    error_column_name: str
    warning_column_name: str
    run_time_overwrite: datetime | None = None
    observed_metrics: dict[str, Any] | None = None
    input_location: str | None = None
    output_location: str | None = None
    quarantine_location: str | None = None
    checks_location: str | None = None
    rule_set_fingerprint: str | None = None
    user_metadata: dict[str, str] | None = None


@dataclass
class DQMetricsObserver:
    """
    Observation class used to track summary metrics about data quality when validating datasets with DQX

    Args:
        name: Name of the observations which will be displayed in listener metrics (default is 'dqx').
            Also used as run_name field when saving the metrics to a table.
        custom_metrics: Optional list of SQL expressions defining custom, dataset-level quality metrics
    """

    name: str = "dqx"
    custom_metrics: list[str] | None = None
    id_overwrite: str | None = None

    _error_column_name: str = "_errors"
    _warning_column_name: str = "_warnings"

    @cached_property
    def id(self) -> str:
        """
        ID of the observer.

        Returns:
            Unique ID
        """
        return self.id_overwrite or str(uuid4())

    def get_metrics(self, check_names: list[str] | None = None) -> list[str]:
        """
        Gets the observer metrics as Spark SQL expressions.

        Args:
            check_names: Optional list of check names from the applied quality rules.
                When provided, a per-check breakdown (*check_metrics*) is included.

        Returns:
            A list of Spark SQL expressions defining the observer metrics (default, per-check, and custom).
        """
        metrics = [
            "count(1) as input_row_count",
            f"count(case when {self._error_column_name} is not null then 1 end) as error_row_count",
            f"count(case when {self._warning_column_name} is not null then 1 end) as warning_row_count",
            f"count(case when {self._error_column_name} is null and {self._warning_column_name} is null then 1 end) as valid_row_count",
        ]
        if check_names:
            metrics.append(self._build_check_metrics_expr(check_names))
        if self.custom_metrics:
            metrics.extend(self.custom_metrics)
        return metrics

    def _build_check_metrics_expr(self, check_names: list[str]) -> str:
        """Build a single SQL expression that produces a per-check breakdown.

        Produces the canonical JSON array string directly from SQL using concat and
        concat_ws over the per-check aggregates. The result is a plain string scalar,
        so *observation.get* sees *check_metrics* as a JSON-encoded string identical
        to the pre-fix shape.

        Two Spark Connect constraints drive this concat-based approach:
          * Server-side to_json on struct aggregates inside observe() has been observed
            to fail intermittently with JsonGenerationException:
            Can not write a field name, expecting a value.
          * LiteralExpression in pyspark.sql.connect.expressions can decode
            primitives and arrays of primitives, but not arrays of structs or arrays
            of strings carrying struct data, so we stay in plain string territory.

        Args:
            check_names: List of check names to include in the expression.

        Returns:
            A Spark SQL expression string aliased as *check_metrics*.
        """
        fragments: list[str] = []
        for check_name in check_names:
            check_name_escaped = check_name.replace("'", "''")
            # JSON-encode the check name (handles embedded quotes, backslashes, control chars),
            # then SQL-escape any single quotes for safe inclusion in a literal.
            json_check_name_sql_esc = json.dumps(check_name).replace("'", "''")
            err = self._error_column_name
            warn = self._warning_column_name
            fragments.append(
                f"concat("
                f"'{{\"check_name\":{json_check_name_sql_esc},\"error_count\":',"
                f"cast(count(case when exists({err}, x -> x.name = '{check_name_escaped}') then 1 end) as string),"
                f"',\"warning_count\":',"
                f"cast(count(case when exists({warn}, x -> x.name = '{check_name_escaped}') then 1 end) as string),"
                f"'}}')"
            )
        return f"concat('[', concat_ws(',', {', '.join(fragments)}), ']') as check_metrics"

    @property
    def observation(self) -> Observation:
        """
        Spark Observation which can be attached to a DataFrame to track summary metrics. Metrics will be collected
        when the 1st action is triggered on the attached DataFrame. Subsequent operations on the attached DataFrame
        will not update the observed metrics. See: [PySpark Observation](https://spark.apache.org/docs/latest/api/python/reference/pyspark.sql/api/pyspark.sql.Observation.html)
        for complete documentation.

        Returns:
            A Spark Observation instance
        """
        return Observation()

    def set_column_names(self, error_column_name: str, warning_column_name: str) -> None:
        """
        Sets the default column names (e.g. *_errors* and *_warnings*) for monitoring summary metrics.

        Args:
            error_column_name: Error column name
            warning_column_name: Warning column name
        """
        self._error_column_name = error_column_name
        self._warning_column_name = warning_column_name

    @staticmethod
    def build_metrics_df(spark: SparkSession, observation: DQMetricsObservation) -> DataFrame:
        """
        Builds a Spark DataFrame from a DQMetricsObservation.

        Args:
            spark: SparkSession used to create the DataFrame
            observation: DQMetricsObservation with summary metrics

        Returns:
            A Spark DataFrame with summary metrics
        """

        if not observation.observed_metrics:
            return spark.createDataFrame([], schema=OBSERVATION_TABLE_SCHEMA)

        df = spark.createDataFrame(
            [
                [
                    observation.run_id,
                    observation.run_name,
                    observation.input_location,
                    observation.output_location,
                    observation.quarantine_location,
                    observation.checks_location,
                    observation.rule_set_fingerprint,
                    metric_key,
                    metric_value,
                    observation.run_time_overwrite,
                    observation.error_column_name,
                    observation.warning_column_name,
                    observation.user_metadata if observation.user_metadata else None,
                ]
                for metric_key, metric_value in observation.observed_metrics.items()
            ],
            schema=OBSERVATION_TABLE_SCHEMA,
        )

        if observation.run_time_overwrite is None:
            df = df.withColumn("run_time", F.current_timestamp())

        return df

    @staticmethod
    def build_metrics_df_from_aggregation(aggregated_df: DataFrame, observation: DQMetricsObservation) -> DataFrame:
        """
        Reshapes a one-row wide aggregation of metric expressions into the long-format
        *OBSERVATION_TABLE_SCHEMA*, without triggering a Spark action.

        Used by *DQEngine.compute_summary_metrics* to keep a lazily-computed aggregation lazy, so the
        result can back a materialized view or table in a Spark Declarative Pipeline (where the pipeline
        runtime — not the caller — triggers the write). The already-collected path uses *build_metrics_df*.

        The input must be a **single-row global aggregation** (the output of *get_metrics* selected with no
        *groupBy*). A multi-row input would emit one metrics row-set per input row, each stamped with the
        same run metadata and no grouping key, so this must not be used for windowed/grouped aggregations.
        The single-row property is guaranteed by construction — the only caller
        (*DQEngine.compute_summary_metrics*) feeds *get_metrics* aggregates selected without *groupBy*,
        which always yield exactly one row — and is intentionally not enforced with a runtime row-count
        check: counting the rows would trigger a Spark action and defeat this method's whole purpose of
        staying lazy so it can back a Spark Declarative Pipeline materialized view.

        Args:
            aggregated_df: A single-row DataFrame whose columns are the metric expressions produced by
                *DQMetricsObserver.get_metrics* (e.g. *input_row_count*, *error_row_count*, *check_metrics*).
            observation: *DQMetricsObservation* carrying the run metadata (locations, fingerprint, run time).

        Returns:
            A lazy Spark DataFrame matching *OBSERVATION_TABLE_SCHEMA* with one row per metric.
        """
        # Unpivot the wide one-row aggregation into (metric_name, metric_value) rows using the DataFrame
        # API: build one struct per metric (name literal + value cast to string) and explode.
        #
        # Reference the metric columns by safe positional names, not by their real names: a metric name
        # can contain a dot (e.g. a user-supplied custom_metrics alias), and `aggregated_df["a.b"]` would
        # parse the dot as nested-field access ("field b of column a") rather than a top-level column,
        # misresolving or raising. `toDF` renames the columns positionally (without resolving the old
        # names), so the value lookup uses a dot-free name; the real name is only used as a literal for
        # metric_name, where a dot is harmless. This avoids SQL-string building and identifier escaping.
        metric_names = aggregated_df.columns
        renamed = aggregated_df.toDF(*[f"metric_{i}" for i in range(len(metric_names))])
        metric_pairs = F.array(
            *[
                F.struct(
                    F.lit(metric_names[i]).alias("metric_name"),
                    renamed[f"metric_{i}"].cast("string").alias("metric_value"),
                )
                for i in range(len(metric_names))
            ]
        )
        long_df = renamed.select(F.explode(metric_pairs).alias("metric"))

        # run_time_overwrite is a datetime, so F.lit produces a timestamp literal via the same
        # Python->Spark conversion createDataFrame uses in build_metrics_df — run_time is therefore
        # identical across both builders. Fall back to current_timestamp() when it is not set.
        if observation.run_time_overwrite is not None:
            run_time = F.lit(observation.run_time_overwrite).cast("timestamp")
        else:
            run_time = F.current_timestamp()

        if observation.user_metadata:
            map_entries = [F.lit(item) for pair in observation.user_metadata.items() for item in pair]
            user_metadata = F.create_map(*map_entries)
        else:
            user_metadata = F.lit(None).cast("map<string, string>")

        return long_df.select(
            F.lit(observation.run_id).cast("string").alias("run_id"),
            F.lit(observation.run_name).cast("string").alias("run_name"),
            F.lit(observation.input_location).cast("string").alias("input_location"),
            F.lit(observation.output_location).cast("string").alias("output_location"),
            F.lit(observation.quarantine_location).cast("string").alias("quarantine_location"),
            F.lit(observation.checks_location).cast("string").alias("checks_location"),
            F.lit(observation.rule_set_fingerprint).cast("string").alias("rule_set_fingerprint"),
            F.col("metric.metric_name").alias("metric_name"),
            F.col("metric.metric_value").alias("metric_value"),
            run_time.alias("run_time"),
            F.lit(observation.error_column_name).cast("string").alias("error_column_name"),
            F.lit(observation.warning_column_name).cast("string").alias("warning_column_name"),
            user_metadata.alias("user_metadata"),
        )
