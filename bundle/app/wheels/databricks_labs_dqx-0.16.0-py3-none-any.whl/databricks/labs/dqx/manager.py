import inspect
import logging
from datetime import datetime
from dataclasses import dataclass
from functools import cached_property

import pyspark.sql.functions as F
from pyspark.errors import AnalysisException
from pyspark.sql import DataFrame, Column, SparkSession

from databricks.labs.dqx import check_funcs
from databricks.labs.dqx.executor import DQCheckResult, DQRuleExecutorFactory
from databricks.labs.dqx.rule import (
    DQRule,
)
from databricks.labs.dqx.schema.dq_result_schema import dq_result_item_schema
from databricks.labs.dqx.utils import (
    get_column_name_or_alias,
    is_simple_column_expression,
    quote_column_name,
    is_sql_query_safe,
    safe_filter_expr,
    sanitize_for_logging,
)

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class DQRuleManager:
    """
    Orchestrates the application of a data quality rule to a DataFrame and builds the final check result.

    The manager is responsible for:
    - Executing the rule using the appropriate row or dataset executor.
    - Applying any filter condition specified in the rule to the check result.
    - Combining user-defined and engine-provided metadata into the result.
    - Constructing the final structured output (including check name, function, columns, metadata, etc.)
      as a DQCheckResult.

    The manager does not implement the logic of individual checks. Instead, it delegates
    rule application to the appropriate DQRuleExecutor based on the rule type (row-level or dataset-level).

    Attributes:
        check: The DQRule instance that defines the check to apply.
        df: The DataFrame on which to apply the check.
        engine_user_metadata: Metadata provided by the engine (overridden by check.user_metadata if present).
        run_time_overwrite: Optional timestamp override. If None, current_timestamp() is used for per-micro-batch timestamps.
        ref_dfs: Optional reference DataFrames for dataset-level checks.
        run_id: Optional unique run id.
    """

    check: DQRule
    df: DataFrame
    spark: SparkSession
    engine_user_metadata: dict[str, str]
    run_time_overwrite: datetime | None
    run_id: str
    ref_dfs: dict[str, DataFrame] | None = None
    suppress_skipped: bool = False
    rule_fingerprint: str | None = None
    rule_set_fingerprint: str | None = None

    @cached_property
    def user_metadata(self) -> dict[str, str]:
        """
        Returns user metadata as a dictionary.
        """
        if self.check.user_metadata is not None:
            # Checks defined in the user metadata override checks defined in the engine
            return (self.engine_user_metadata or {}) | self.check.user_metadata
        return self.engine_user_metadata or {}

    @cached_property
    def filter_condition(self) -> Column:
        """
        Returns the filter condition for the check.
        """
        return safe_filter_expr(self.check.filter)

    @cached_property
    def _effective_filter(self) -> str | None:
        """
        Returns the filter string that will be applied for this check, or None.

        This is the single source of truth for "what filter runs" so the skip decision covers every way a
        filter can reach a check function: the check-level *filter*, and a *row_filter* passed through
        *check_func_kwargs* or positionally via *check_func_args*. Resolving from the check function's bound
        arguments (rather than only *check.filter* / the kwarg) ensures no supply path slips past the guard.
        """
        if self.check.filter:
            return self.check.filter
        args, kwargs = self.check.prepare_check_func_args_and_kwargs()
        row_filter = kwargs.get("row_filter")
        if row_filter is None:
            # row_filter may have been supplied positionally; bind against the signature to locate it.
            sig = inspect.signature(self.check.check_func)
            if "row_filter" in sig.parameters:
                try:
                    bound = sig.bind_partial(*args, **kwargs)
                    row_filter = bound.arguments.get("row_filter")
                except TypeError:
                    row_filter = None
        return row_filter if isinstance(row_filter, str) else None

    @cached_property
    def has_unsafe_filter(self) -> bool:
        """
        Returns True if the check filter contains unsafe SQL (e.g. a destructive statement keyword).

        This is a non-raising check: an unsafe filter causes the check to be skipped (like any other
        invalid filter) rather than aborting evaluation of the whole rule set. Note this does not apply to
        the *sql_query* check, whose query runs via *spark.sql* and is still hard-rejected in the executor.
        """
        filter_expr = self._effective_filter
        if not filter_expr:
            return False
        return not is_sql_query_safe(filter_expr)

    @cached_property
    def invalid_columns(self) -> list[str]:
        """
        Returns list of invalid check columns in the input DataFrame.

        Column names that contain characters requiring SQL identifier escaping (e.g. spaces, such as
        "Customer Name") are back-quoted so they are unambiguous in the skip / error messages.
        """
        invalid_cols = []

        if self.check.column is not None and self._is_invalid_column(self.check.column):
            invalid_cols.append(self._display_column_name(self.check.column))
        elif self.check.columns is not None:  # either column or columns can be provided, but not both
            for column in self.check.columns:
                if self._is_invalid_column(column):
                    invalid_cols.append(self._display_column_name(column))

        return invalid_cols

    @staticmethod
    def _display_column_name(column: str | Column) -> str:
        """
        Returns the column name for use in skip / error messages, back-quoting names that require SQL
        identifier escaping (e.g. "Customer Name" -> "`Customer Name`").
        """
        name = get_column_name_or_alias(column)
        if is_simple_column_expression(name) or (name.startswith("`") and name.endswith("`")):
            return name
        return quote_column_name(name)

    @cached_property
    def has_invalid_columns(self) -> bool:
        """
        Returns a boolean indicating whether any of the specified check columns are invalid in the input DataFrame.
        """
        return bool(self.invalid_columns)

    @cached_property
    def has_invalid_filter(self) -> bool:
        """
        Returns a boolean indicating whether the filter is invalid in the input DataFrame.

        An unsafe filter is short-circuited here so that ``filter_condition`` (which rejects unsafe SQL by
        raising) is never compiled for it; the check is reported as skipped via ``_get_invalid_cols_message``.
        """
        if self.has_unsafe_filter:
            return True
        return self._is_invalid_column(self.filter_condition)

    @cached_property
    def has_invalid_custom_message(self) -> bool:
        """
        Returns a boolean indicating whether the custom message expression is invalid in the input DataFrame.
        """
        if self.check.message_expr is None:
            return False
        return self._is_invalid_column(self.check.message_expr)

    @cached_property
    def invalid_sql_expression(self) -> str | None:
        """
        Returns an invalid expression for sql expression check.
        """
        if self.check.check_func is check_funcs.sql_expression:
            if "expression" in self.check.check_func_kwargs:
                field_value = self.check.check_func_kwargs["expression"]
            elif self.check.check_func_args:
                field_value = self.check.check_func_args[0]
            else:
                return None  # should never happen, as it is validated for correct args when building rules

            if self._is_invalid_column(field_value):
                return field_value
        return None

    def process(self) -> DQCheckResult:
        """
        Process the data quality rule (check) and return results as DQCheckResult containing:
        - Column with the check result
        - optional DataFrame with the results of the check

        Skip the check evaluation if column or columns, or filter in the check cannot be resolved in the input
        DataFrame. Return the check result preserving all fields with message identifying invalid fields.
        """
        invalid_cols_message = self._get_invalid_cols_message()
        if invalid_cols_message:
            if self.suppress_skipped:
                # return null condition so this check produces no entry in _errors/_warnings
                return DQCheckResult(condition=F.lit(None).cast(dq_result_item_schema), check_df=self.df)
            # overwrite message but preserve all other fields in the result, marking the check as skipped
            result_struct = self._build_result_struct(condition=F.lit(invalid_cols_message), skipped=True)
            return DQCheckResult(condition=result_struct, check_df=self.df)

        executor = DQRuleExecutorFactory.create(self.check)
        raw_result = executor.apply(self.df, self.spark, self.ref_dfs)
        return self._wrap_result(raw_result)

    def _wrap_result(self, raw_result: DQCheckResult) -> DQCheckResult:
        result_struct = self._build_result_struct(raw_result.condition)
        check_result = F.when(self.filter_condition & raw_result.condition.isNotNull(), result_struct)
        return DQCheckResult(
            condition=check_result, check_df=raw_result.check_df, info_column_name=raw_result.info_column_name
        )

    def _build_result_struct(self, condition: Column, skipped: bool = False) -> Column:
        # Use current_timestamp() to make sure streaming gets per-micro-batch timestamps,
        # or use literal run time if explicitly overridden
        run_time_expr = F.current_timestamp() if self.run_time_overwrite is None else F.lit(self.run_time_overwrite)

        message_col = self._build_message_col(condition, skipped=skipped)

        return F.struct(
            F.lit(self.check.name).alias("name"),
            message_col.alias("message"),
            self.check.columns_as_string_expr.alias("columns"),
            F.lit(self.check.filter or None).cast("string").alias("filter"),
            F.lit(self.check.check_func.__name__).alias("function"),
            run_time_expr.alias("run_time"),
            F.lit(self.run_id).alias("run_id"),
            # Cast keys and values to string so a mixed-type user_metadata (e.g. {"k": 2}) still
            # produces a MAP<STRING, STRING> matching dq_result_item_schema. Without the cast,
            # create_map infers a single value type (e.g. BIGINT) and fails to cast string values
            # (CAST_INVALID_INPUT) when the dict mixes strings and numbers.
            F.create_map(
                *[
                    item
                    for key, value in self.user_metadata.items()
                    for item in (F.lit(key).cast("string"), F.lit(value).cast("string"))
                ]
            ).alias("user_metadata"),
            F.lit(self.rule_fingerprint).alias("rule_fingerprint"),
            F.lit(self.rule_set_fingerprint).alias("rule_set_fingerprint"),
            F.lit(skipped or None).alias("skipped"),
        ).cast(dq_result_item_schema)

    def _build_message_col(self, condition: Column, skipped: bool = False) -> Column:
        """
        Builds the message column, using the default message or the user-supplied ``message_expr`` from the
        rule definition. The expression is evaluated as-is. Accepts either a Spark SQL expression string or a
        Spark Column.

        Args:
            condition: Default DQX condition message returned by evaluating the DQX check function
            skipped: Whether the check was skipped (default False)

        Returns:
            The custom DQX condition message if ``message_expr`` is set on the rule and the check was not skipped,
            otherwise the default DQX condition message.
        """
        if skipped:
            return condition

        if self.check.message_expr is None:
            return condition

        _max_message_length = 500
        message_expr = F.substr(
            F.expr(self.check.message_expr) if isinstance(self.check.message_expr, str) else self.check.message_expr,
            F.lit(1),
            F.lit(_max_message_length),
        )

        return F.when(condition.isNotNull(), message_expr).otherwise(F.lit(None).cast("string"))

    def _get_invalid_cols_message(self) -> str:
        """
        Returns invalid columns message containing info about invalid columns to check should be applied to or filter.
        """
        invalid_cols_message_parts = []

        if self.has_invalid_columns:
            logger.warning(
                f"Skipping check evaluation '{self.check.name}' due to invalid check columns: {self.invalid_columns}"
            )
            invalid_cols_message_parts.append(
                f"Check evaluation skipped due to invalid check columns: {self.invalid_columns}"
            )

        if self.has_unsafe_filter:
            safe_filter = sanitize_for_logging(self._effective_filter or "")
            logger.warning(f"Skipping check '{self.check.name}' due to unsafe check filter: '{safe_filter}'")
            invalid_cols_message_parts.append(f"Check evaluation skipped due to unsafe check filter: '{safe_filter}'")
        elif self.has_invalid_filter:
            safe_filter = sanitize_for_logging(self.check.filter or "")
            logger.warning(f"Skipping check '{self.check.name}' due to invalid check filter: '{safe_filter}'")
            invalid_cols_message_parts.append(f"Check evaluation skipped due to invalid check filter: '{safe_filter}'")

        if self.has_invalid_custom_message:
            if isinstance(self.check.message_expr, str):
                custom_message_detail = f": '{self.check.message_expr}'"
            else:
                custom_message_detail = ""
            logger.warning(
                f"Skipping check '{self.check.name}' due to invalid custom message expression{custom_message_detail}"
            )
            invalid_cols_message_parts.append(
                f"Check evaluation skipped due to invalid custom message expression{custom_message_detail}"
            )

        if self.invalid_sql_expression:
            logger.warning(
                f"Skipping check '{self.check.name}' due to invalid sql expression: '{self.invalid_sql_expression}'"
            )
            invalid_cols_message_parts.append(
                f"Check evaluation skipped due to invalid sql expression: '{self.invalid_sql_expression}'"
            )

        invalid_cols_message = "; ".join(invalid_cols_message_parts)

        return invalid_cols_message

    def _is_invalid_column(self, column: str | Column) -> bool:
        """
        Returns True if the specified column is invalid (i.e., cannot be resolved in the input DataFrame),
        otherwise False.
        """
        try:
            col_expr = F.expr(column) if isinstance(column, str) else column
            _ = self.df.select(col_expr).schema  # perform logical plan validation without triggering computation
        except AnalysisException as e:
            # The input string may be a SQL expression (e.g. "a + b") or a plain column name that may require
            # SQL identifier escaping (spaces / non-ASCII / reserved chars, e.g. "Customer Name"). To validate
            # the input string, we first attempt F.expr() and retry failing strings as a backtick-quoted identifiers.
            # String expressions parse cleanly and only genuine single-identifier names pass fallback validation.
            if isinstance(column, str) and not self._is_invalid_quoted_column(column):
                return False
            # If column is not accessible or column expression cannot be evaluated, an AnalysisException is thrown.
            # Note: This does not cover all error conditions. Some issues only appear during a Spark action.
            logger.debug(
                f"Invalid column '{column}' provided in the check '{self.check.name}'",
                exc_info=e,
            )
            return True
        return False

    def _is_invalid_quoted_column(self, column: str) -> bool:
        """
        Returns True if the string cannot be resolved as a single backtick-quoted column identifier,
        otherwise False.
        """
        try:
            _ = self.df.select(F.expr(quote_column_name(column))).schema
        except AnalysisException:
            return True
        return False
